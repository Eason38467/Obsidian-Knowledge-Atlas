const {
  addIcon,
  ItemView,
  Plugin,
  PluginSettingTab,
  Setting,
  TFile
} = require("obsidian");

const VIEW_TYPE = "knowledge-atlas-view";
const ROOT_NOTES = "@root-notes";
const SVG_NS = "http://www.w3.org/2000/svg";
const ICON_ID = "knowledge-atlas-orbit";
const ICON_SVG = `
  <ellipse cx="50" cy="50" rx="42" ry="19" fill="none" stroke="currentColor" stroke-width="6" />
  <ellipse cx="50" cy="50" rx="19" ry="42" fill="none" stroke="currentColor" stroke-width="6" transform="rotate(-35 50 50)" />
  <circle cx="50" cy="50" r="9" fill="currentColor" stroke="none" />
  <circle cx="88" cy="44" r="6" fill="currentColor" stroke="none" />
  <circle cx="33" cy="17" r="5" fill="currentColor" stroke="none" />
`;
const PALETTE = ["#22d3ee", "#5b8cff", "#a855f7", "#f43f8e", "#ff8a34", "#34d399", "#facc15", "#fb7185"];
const DEFAULT_SETTINGS = {
  excludedFolders: [".obsidian", ".trash", "Templates", "assets"],
  maxFolders: 48,
  maxNotes: 54,
  sampleNotes: 18,
  recentLimit: 8,
  openNotesInNewLeaf: false
};

const COPY = {
  en: {
    title: "Knowledge Atlas",
    subtitle: "Explore folders, notes, and the links between them.",
    notes: "notes",
    folders: "folders",
    links: "links",
    search: "Search every note…",
    back: "← Back",
    overview: "⌂ Overview",
    orbit: "Orbit",
    tree: "Tree",
    refresh: "Refresh",
    inspector: "Signal inspector",
    inspectHint: "Hover a node for details. Open a folder to drill down or a note to read it.",
    openNote: "Open note",
    legend: "Visual language",
    readGraph: "How to read",
    folder: "Folder / drill down",
    note: "Note / open",
    noteLink: "Note link",
    sample: "Recent sample",
    recent: "Recently updated",
    collapsed: "The overview is collapsed. Select a knowledge area to begin.",
    complete: "All nodes in this level are visible. Dashed lines are real note links.",
    moreFolders: "more folders",
    moreNotes: "more notes",
    hiddenHint: "Continue drilling down or use search.",
    noResults: "No matching notes. Try a title or folder name.",
    noNotes: "No Markdown notes are available with the current exclusions.",
    orbitHint: "Orbit · wheel to zoom · drag to pan",
    treeHint: "Tree · wheel to zoom · drag to pan",
    rootNotes: "Root notes"
  },
  zh: {
    title: "知识星图",
    subtitle: "沿目录浏览笔记，并发现它们之间的真实双链。",
    notes: "笔记",
    folders: "目录",
    links: "链接",
    search: "搜索全部笔记…",
    back: "← 返回",
    overview: "⌂ 总览",
    orbit: "星图",
    tree: "树状",
    refresh: "刷新",
    inspector: "节点信息",
    inspectHint: "悬停查看详情；点击目录继续下钻，点击笔记直接打开。",
    openNote: "打开笔记",
    legend: "视觉语言",
    readGraph: "读图方式",
    folder: "目录 / 下钻",
    note: "笔记 / 打开",
    noteLink: "双链关系",
    sample: "最近采样",
    recent: "最近更新",
    collapsed: "默认折叠显示知识域；选择一个知识域开始探索。",
    complete: "当前层级节点已完整显示；虚线表示真实双链。",
    moreFolders: "个目录未绘制",
    moreNotes: "篇笔记未绘制",
    hiddenHint: "可继续下钻或使用搜索。",
    noResults: "没有找到匹配笔记，可尝试标题或目录名称。",
    noNotes: "按当前排除规则，没有可显示的 Markdown 笔记。",
    orbitHint: "星图 · 滚轮缩放 · 拖动画布",
    treeHint: "树状 · 滚轮缩放 · 拖动画布",
    rootNotes: "根目录笔记"
  }
};

function createElement(parent, tag, className, text) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (text !== undefined) element.textContent = text;
  parent.appendChild(element);
  return element;
}

function createButton(parent, className, text, label) {
  const button = createElement(parent, "button", className, text);
  button.type = "button";
  if (label) button.setAttribute("aria-label", label);
  return button;
}

function createSvg(tag, attributes = {}) {
  const element = document.createElementNS(SVG_NS, tag);
  for (const [key, value] of Object.entries(attributes)) element.setAttribute(key, String(value));
  return element;
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function shortLabel(value, length = 20) {
  const text = String(value || "");
  return text.length > length ? `${text.slice(0, length - 1)}…` : text;
}

function topLevel(path) {
  return String(path || "").split("/")[0] || ROOT_NOTES;
}

function stableColor(path) {
  const value = topLevel(path);
  let hash = 0;
  for (let index = 0; index < value.length; index += 1) hash = ((hash << 5) - hash + value.charCodeAt(index)) | 0;
  return PALETTE[Math.abs(hash) % PALETTE.length];
}

function formatDate(timestamp, includeTime = false) {
  if (!timestamp) return "";
  const date = new Date(timestamp);
  const options = includeTime
    ? { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" }
    : { month: "2-digit", day: "2-digit" };
  return new Intl.DateTimeFormat(undefined, options).format(date);
}

class KnowledgeAtlasView extends ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.plugin = plugin;
    this.currentFocus = "";
    this.currentLayout = "radial";
    this.selectedNode = null;
    this.viewport = null;
    this.viewTransform = { x: 0, y: 0, k: 1 };
    this.panState = null;
    this.isChinese = (navigator.language || "").toLowerCase().startsWith("zh");
    this.copy = this.isChinese ? COPY.zh : COPY.en;
  }

  getViewType() {
    return VIEW_TYPE;
  }

  getDisplayText() {
    return "Knowledge Atlas";
  }

  getIcon() {
    return ICON_ID;
  }

  async onOpen() {
    this.render();
  }

  async onClose() {}

  isExcluded(path) {
    return this.plugin.settings.excludedFolders.some(prefix => path === prefix || path.startsWith(`${prefix}/`));
  }

  buildModel() {
    const files = this.app.vault.getMarkdownFiles().filter(file => !this.isExcluded(file.path));
    const folders = new Map();

    const ensureFolder = (path, displayName) => {
      if (!folders.has(path)) {
        const parts = path === ROOT_NOTES ? [] : path.split("/");
        folders.set(path, {
          path,
          name: displayName || parts.at(-1) || this.copy.rootNotes,
          parent: path === ROOT_NOTES || parts.length <= 1 ? "" : parts.slice(0, -1).join("/"),
          children: new Set(),
          files: [],
          count: 0
        });
      }
      return folders.get(path);
    };

    for (const file of files) {
      const folderPath = file.parent?.path || "";
      if (!folderPath || folderPath === "/") {
        const root = ensureFolder(ROOT_NOTES, this.copy.rootNotes);
        root.files.push(file);
        root.count += 1;
        continue;
      }
      const parts = folderPath.split("/").filter(Boolean);
      for (let index = 0; index < parts.length; index += 1) {
        const path = parts.slice(0, index + 1).join("/");
        const folder = ensureFolder(path);
        folder.count += 1;
        if (index > 0) ensureFolder(parts.slice(0, index).join("/")).children.add(path);
      }
      ensureFolder(folderPath).files.push(file);
    }

    const roots = [...folders.values()]
      .filter(folder => folder.parent === "")
      .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
    let linkCount = 0;
    for (const file of files) {
      const resolved = this.app.metadataCache.resolvedLinks[file.path] || {};
      linkCount += Object.values(resolved).reduce((sum, count) => sum + Number(count || 0), 0);
    }
    return { files, folders, roots, linkCount };
  }

  render() {
    this.contentEl.empty();
    this.contentEl.addClass("knowledge-atlas-plugin-view");
    this.model = this.buildModel();
    if (this.currentFocus && !this.model.folders.has(this.currentFocus)) this.currentFocus = "";

    const root = createElement(this.contentEl, "div", "kap-root");
    const header = createElement(root, "header", "kap-header");
    const titleWrap = createElement(header, "div", "kap-title-wrap");
    createElement(titleWrap, "div", "kap-kicker", "VAULT / KNOWLEDGE ATLAS");
    createElement(titleWrap, "h1", "kap-title", this.copy.title);
    createElement(titleWrap, "p", "kap-subtitle", this.copy.subtitle);
    const stats = createElement(header, "div", "kap-stats");
    [[this.model.files.length, this.copy.notes], [this.model.folders.size, this.copy.folders], [this.model.linkCount, this.copy.links]].forEach(([value, label]) => {
      const item = createElement(stats, "div", "kap-stat");
      createElement(item, "strong", "kap-stat-value", Number(value).toLocaleString());
      createElement(item, "span", "kap-stat-label", label);
    });

    const toolbar = createElement(root, "div", "kap-toolbar");
    const searchWrap = createElement(toolbar, "div", "kap-search-wrap");
    const searchIcon = createElement(searchWrap, "span", "kap-search-icon");
    searchIcon.setAttribute("aria-hidden", "true");
    this.searchInput = createElement(searchWrap, "input", "kap-search");
    this.searchInput.type = "search";
    this.searchInput.placeholder = this.copy.search;
    this.searchInput.setAttribute("aria-label", this.copy.search);
    this.searchResults = createElement(searchWrap, "div", "kap-search-results");
    const controls = createElement(toolbar, "div", "kap-controls");
    this.backButton = createButton(controls, "kap-button", this.copy.back);
    this.overviewButton = createButton(controls, "kap-button", this.copy.overview);
    this.orbitButton = createButton(controls, "kap-button is-active", this.copy.orbit);
    this.treeButton = createButton(controls, "kap-button", this.copy.tree);
    this.refreshButton = createButton(controls, "kap-button", "↻", this.copy.refresh);

    this.domainRail = createElement(root, "div", "kap-domain-rail");
    this.renderDomainRail();

    const body = createElement(root, "div", "kap-body");
    this.stage = createElement(body, "section", "kap-stage");
    const stageHeader = createElement(this.stage, "div", "kap-stage-header");
    this.breadcrumbs = createElement(stageHeader, "div", "kap-breadcrumbs");
    this.viewHint = createElement(stageHeader, "div", "kap-view-hint");
    this.graph = createSvg("svg", { class: "kap-graph", viewBox: "0 0 1200 680", role: "img", "aria-label": "Interactive knowledge atlas" });
    this.stage.appendChild(this.graph);
    this.limitNote = createElement(this.stage, "div", "kap-limit-note");
    this.createZoomControls();

    const dock = createElement(body, "aside", "kap-dock");
    const inspector = createElement(dock, "section", "kap-panel");
    createElement(inspector, "div", "kap-panel-kicker", this.copy.inspector);
    this.inspectTitle = createElement(inspector, "h2", "kap-panel-title", this.copy.title);
    this.inspectMeta = createElement(inspector, "p", "kap-panel-meta", this.copy.inspectHint);
    this.inspectAction = createButton(inspector, "kap-panel-action", this.copy.openNote);

    const legendPanel = createElement(dock, "section", "kap-panel");
    createElement(legendPanel, "div", "kap-panel-kicker", this.copy.legend);
    createElement(legendPanel, "h2", "kap-panel-title", this.copy.readGraph);
    const legend = createElement(legendPanel, "div", "kap-legend");
    [["folder", this.copy.folder, PALETTE[1]], ["note", this.copy.note, PALETTE[0]], ["link", this.copy.noteLink, PALETTE[3]], ["sample", this.copy.sample, PALETTE[4]]].forEach(([type, label, color]) => {
      const item = createElement(legend, "div", "kap-legend-item");
      const mark = createElement(item, "span", `kap-legend-mark ${type === "folder" ? "is-folder" : ""}`);
      mark.style.setProperty("--kap-legend-color", color);
      createElement(item, "span", "", label);
    });

    const recentPanel = createElement(dock, "section", "kap-panel kap-recent-panel");
    createElement(recentPanel, "div", "kap-panel-kicker", "FRESH SIGNALS");
    createElement(recentPanel, "h2", "kap-panel-title", this.copy.recent);
    this.recentList = createElement(recentPanel, "div", "kap-recent-list");
    this.renderRecent();
    this.bindControls();

    if (!this.model.files.length) {
      this.graph.replaceWith(createElement(document.createDocumentFragment(), "div", "kap-empty", this.copy.noNotes));
    } else {
      this.setFocus(this.currentFocus || "");
    }
  }

  renderDomainRail() {
    this.domainRail.replaceChildren();
    for (const folder of this.model.roots) {
      const button = createButton(this.domainRail, "kap-domain", `${folder.name} · ${folder.count}`);
      button.style.setProperty("--kap-domain-color", stableColor(folder.path));
      button.addEventListener("click", () => this.setFocus(folder.path));
    }
  }

  renderRecent() {
    this.recentList.replaceChildren();
    [...this.model.files]
      .sort((a, b) => b.stat.mtime - a.stat.mtime)
      .slice(0, this.plugin.settings.recentLimit)
      .forEach(file => {
        const button = createButton(this.recentList, "kap-recent", file.basename);
        button.replaceChildren();
        const bar = createElement(button, "span", "kap-recent-bar");
        bar.style.setProperty("--kap-recent-color", stableColor(file.path));
        const copy = createElement(button, "span", "kap-recent-copy");
        createElement(copy, "span", "kap-recent-title", file.basename);
        createElement(copy, "span", "kap-recent-path", file.parent?.path || this.copy.rootNotes);
        createElement(button, "span", "kap-recent-date", formatDate(file.stat.mtime));
        button.addEventListener("click", () => this.openNote(file.path));
      });
  }

  getVisibleGraph() {
    const settings = this.plugin.settings;
    const focusFolder = this.currentFocus ? this.model.folders.get(this.currentFocus) : null;
    const center = {
      id: "center",
      type: "center",
      label: focusFolder?.name || "VAULT",
      path: this.currentFocus || "VAULT",
      color: stableColor(this.currentFocus || "Knowledge Atlas"),
      detail: focusFolder
        ? `${focusFolder.count} ${this.copy.notes} · ${focusFolder.children.size} ${this.copy.folders}`
        : `${this.model.files.length} ${this.copy.notes} · ${this.model.roots.length} ${this.copy.folders}`
    };
    const childFolders = (this.currentFocus
      ? [...(focusFolder?.children || [])].map(path => this.model.folders.get(path))
      : this.model.roots)
      .filter(Boolean)
      .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
    const visibleFolders = childFolders.slice(0, settings.maxFolders);
    const folderNodes = visibleFolders.map(folder => ({
      id: `folder:${folder.path}`,
      type: "folder",
      label: folder.name,
      path: folder.path,
      color: stableColor(folder.path),
      count: folder.count,
      detail: `${folder.count} ${this.copy.notes} · ${folder.children.size} ${this.copy.folders}`
    }));

    let candidateNotes = this.currentFocus ? [...(focusFolder?.files || [])] : [];
    const sampled = new Set();
    if (this.currentFocus && this.currentFocus !== ROOT_NOTES && candidateNotes.length < settings.sampleNotes) {
      const descendants = this.model.files
        .filter(file => file.path.startsWith(`${this.currentFocus}/`))
        .filter(file => !candidateNotes.some(item => item.path === file.path))
        .sort((a, b) => b.stat.mtime - a.stat.mtime);
      for (const file of descendants.slice(0, settings.sampleNotes - candidateNotes.length)) {
        candidateNotes.push(file);
        sampled.add(file.path);
      }
    }
    candidateNotes = candidateNotes.sort((a, b) => b.stat.mtime - a.stat.mtime).slice(0, settings.maxNotes);
    const noteNodes = candidateNotes.map(file => ({
      id: `note:${file.path}`,
      type: "note",
      label: file.basename,
      path: file.path,
      color: stableColor(file.path),
      sample: sampled.has(file.path),
      file,
      detail: `${file.parent?.path || this.copy.rootNotes} · ${formatDate(file.stat.mtime, true)}`
    }));

    const nodes = [center, ...folderNodes, ...noteNodes];
    const edges = folderNodes.map(node => ({ source: "center", target: node.id, type: "tree", color: node.color }));
    const folderIds = new Map(folderNodes.map(node => [node.path, node.id]));
    for (const note of noteNodes) {
      let parent = "center";
      if (note.sample) {
        const match = [...folderIds.keys()].filter(path => note.path.startsWith(`${path}/`)).sort((a, b) => b.length - a.length)[0];
        if (match) parent = folderIds.get(match);
      }
      edges.push({ source: parent, target: note.id, type: "tree", color: note.color });
    }

    const visibleNoteIds = new Map(noteNodes.map(node => [node.path, node.id]));
    const crossLinks = new Set();
    for (const note of noteNodes) {
      const resolved = this.app.metadataCache.resolvedLinks[note.path] || {};
      for (const targetPath of Object.keys(resolved)) {
        const target = visibleNoteIds.get(targetPath);
        if (!target || target === note.id) continue;
        const key = [note.id, target].sort().join("::");
        if (crossLinks.has(key)) continue;
        crossLinks.add(key);
        edges.push({ source: note.id, target, type: "cross", color: note.color });
      }
    }
    return {
      nodes,
      edges,
      hiddenFolders: Math.max(0, childFolders.length - visibleFolders.length),
      hiddenNotes: Math.max(0, (focusFolder?.files.length || 0) - candidateNotes.filter(file => !sampled.has(file.path)).length)
    };
  }

  radialLayout(nodes, edges) {
    const positions = new Map([["center", { x: 600, y: 350 }]]);
    const folders = nodes.filter(node => node.type === "folder");
    const notes = nodes.filter(node => node.type === "note");
    const folderAngles = new Map();
    folders.forEach((node, index) => {
      const angle = -Math.PI / 2 + (index / Math.max(folders.length, 1)) * Math.PI * 2;
      const radius = folders.length > 16 && index % 2 ? 260 : 205;
      folderAngles.set(node.id, angle);
      positions.set(node.id, { x: 600 + Math.cos(angle) * radius, y: 350 + Math.sin(angle) * radius });
    });
    const parentByNote = new Map(edges.filter(edge => edge.type === "tree" && edge.target.startsWith("note:")).map(edge => [edge.target, edge.source]));
    const groups = new Map();
    for (const note of notes) {
      const parent = parentByNote.get(note.id) || "center";
      if (!groups.has(parent)) groups.set(parent, []);
      groups.get(parent).push(note);
    }
    for (const [parent, group] of groups) {
      const base = folderAngles.get(parent) ?? -Math.PI / 2;
      const spread = parent === "center" ? Math.PI * 2 : Math.min(1.65, .28 + group.length * .12);
      group.forEach((node, index) => {
        const angle = base - spread / 2 + ((index + .5) / Math.max(group.length, 1)) * spread;
        const radius = [286, 326, 362][index % 3];
        positions.set(node.id, { x: 600 + Math.cos(angle) * radius, y: 350 + Math.sin(angle) * radius });
      });
    }
    return positions;
  }

  treeLayout(nodes, edges) {
    const positions = new Map([["center", { x: 115, y: 350 }]]);
    const folders = nodes.filter(node => node.type === "folder");
    const notes = nodes.filter(node => node.type === "note");
    const columns = Math.max(1, Math.ceil(folders.length / 10));
    const rows = Math.max(1, Math.ceil(folders.length / columns));
    folders.forEach((node, index) => {
      const column = Math.floor(index / rows);
      const row = index % rows;
      positions.set(node.id, {
        x: columns === 1 ? 420 : 270 + column * (440 / Math.max(columns - 1, 1)),
        y: 72 + (row + .5) * (556 / rows)
      });
    });
    notes.forEach((node, index) => positions.set(node.id, {
      x: index % 2 ? 1060 : 850,
      y: 60 + (index + .5) * (580 / Math.max(notes.length, 1))
    }));
    return positions;
  }

  curvePath(source, target) {
    if (this.currentLayout === "tree") {
      const middle = (source.x + target.x) / 2;
      return `M ${source.x} ${source.y} C ${middle} ${source.y}, ${middle} ${target.y}, ${target.x} ${target.y}`;
    }
    const cx = 600 + (source.x + target.x - 1200) * .13;
    const cy = 350 + (source.y + target.y - 700) * .13;
    return `M ${source.x} ${source.y} Q ${cx} ${cy} ${target.x} ${target.y}`;
  }

  renderGraph() {
    this.graph.replaceChildren();
    this.renderBreadcrumbs();
    const data = this.getVisibleGraph();
    const positions = this.currentLayout === "radial" ? this.radialLayout(data.nodes, data.edges) : this.treeLayout(data.nodes, data.edges);
    this.viewHint.textContent = this.currentLayout === "radial" ? this.copy.orbitHint : this.copy.treeHint;
    this.viewport = createSvg("g", { class: "kap-viewport" });
    this.graph.appendChild(this.viewport);
    this.applyViewTransform();
    if (this.currentLayout === "radial") {
      this.viewport.appendChild(createSvg("circle", { cx: 600, cy: 350, r: 205, class: "kap-orbit" }));
      this.viewport.appendChild(createSvg("circle", { cx: 600, cy: 350, r: 292, class: "kap-orbit kap-orbit-secondary" }));
    }

    const edgeLayer = createSvg("g", { class: "kap-edges" });
    const edgeElements = [];
    for (const edge of data.edges) {
      const source = positions.get(edge.source);
      const target = positions.get(edge.target);
      if (!source || !target) continue;
      const path = createSvg("path", {
        d: this.curvePath(source, target),
        fill: "none",
        class: `kap-edge ${edge.type === "cross" ? "is-cross" : ""}`,
        "data-source": edge.source,
        "data-target": edge.target
      });
      path.style.setProperty("--kap-edge-color", edge.color);
      edgeLayer.appendChild(path);
      edgeElements.push({ edge, path });
    }
    this.viewport.appendChild(edgeLayer);

    const nodeLayer = createSvg("g", { class: "kap-nodes" });
    const noteParents = new Map(data.edges.filter(edge => edge.type === "tree" && edge.target.startsWith("note:")).map(edge => [edge.target, edge.source]));
    const labelCounts = new Map();
    for (const node of data.nodes) {
      const position = positions.get(node.id);
      if (!position) continue;
      const group = createSvg("g", {
        class: `kap-node kap-node-${node.type}`,
        transform: `translate(${position.x} ${position.y})`,
        tabindex: "0",
        role: "button",
        "aria-label": node.label
      });
      group.style.setProperty("--kap-node-color", node.color);
      const haloRadius = node.type === "center" ? 42 : node.type === "folder" ? 26 : 13;
      const coreRadius = node.type === "center" ? 24 : node.type === "folder" ? 13 : 4.2;
      group.appendChild(createSvg("circle", { class: "kap-halo", r: haloRadius }));
      group.appendChild(createSvg("circle", { class: "kap-core", r: coreRadius }));
      if (node.type === "folder") {
        const count = createSvg("text", { x: 0, y: 3, "text-anchor": "middle", class: "kap-label" });
        count.textContent = String(node.count);
        group.appendChild(count);
      }
      let collapse = false;
      if (node.type === "note" && this.currentLayout === "radial") {
        const parent = noteParents.get(node.id) || "center";
        const count = labelCounts.get(parent) || 0;
        collapse = count >= 7;
        labelCounts.set(parent, count + 1);
      }
      const sideFolderLabel = node.type === "folder" && this.currentLayout === "tree";
      const label = createSvg("text", {
        x: node.type === "note" ? 10 : sideFolderLabel ? 20 : 0,
        y: node.type === "center" ? 46 : sideFolderLabel ? 3 : node.type === "folder" ? 32 : 3,
        "text-anchor": node.type === "note" || sideFolderLabel ? "start" : "middle",
        class: `kap-label ${collapse ? "is-collapsed" : ""}`.trim()
      });
      label.textContent = shortLabel(node.label, node.type === "note" ? 24 : 18);
      group.appendChild(label);

      const illuminate = active => {
        for (const item of edgeElements) {
          if (item.edge.source === node.id || item.edge.target === node.id) item.path.classList.toggle("is-lit", active);
        }
      };
      group.addEventListener("mouseenter", () => { this.updateInspector(node); illuminate(true); });
      group.addEventListener("mouseleave", () => illuminate(false));
      const activate = () => {
        if (node.type === "note") this.openNote(node.path);
        else if (node.type === "folder") this.setFocus(node.path);
        else if (node.type === "center" && this.currentFocus) this.setFocus(this.model.folders.get(this.currentFocus)?.parent || "");
      };
      group.addEventListener("click", activate);
      group.addEventListener("keydown", event => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          activate();
        }
      });
      nodeLayer.appendChild(group);
    }
    this.viewport.appendChild(nodeLayer);

    if (!this.currentFocus) this.limitNote.textContent = this.copy.collapsed;
    else if (data.hiddenFolders || data.hiddenNotes) {
      const parts = [];
      if (data.hiddenFolders) parts.push(`${data.hiddenFolders} ${this.copy.moreFolders}`);
      if (data.hiddenNotes) parts.push(`${data.hiddenNotes} ${this.copy.moreNotes}`);
      this.limitNote.textContent = `${parts.join(" · ")} · ${this.copy.hiddenHint}`;
    } else this.limitNote.textContent = this.copy.complete;
    this.backButton.disabled = !this.currentFocus;
    this.overviewButton.disabled = !this.currentFocus;
    this.updateInspector(null);
  }

  renderBreadcrumbs() {
    this.breadcrumbs.replaceChildren();
    const home = createButton(this.breadcrumbs, "kap-crumb", "VAULT");
    home.addEventListener("click", () => this.setFocus(""));
    if (!this.currentFocus) return;
    if (this.currentFocus === ROOT_NOTES) {
      createElement(this.breadcrumbs, "span", "", "›");
      createElement(this.breadcrumbs, "span", "", this.copy.rootNotes);
      return;
    }
    const parts = this.currentFocus.split("/");
    parts.forEach((part, index) => {
      createElement(this.breadcrumbs, "span", "", "›");
      const button = createButton(this.breadcrumbs, "kap-crumb", part);
      button.addEventListener("click", () => this.setFocus(parts.slice(0, index + 1).join("/")));
    });
  }

  setFocus(path) {
    if (path && !this.model.folders.has(path)) return;
    this.currentFocus = path;
    this.resetView(false);
    this.rootElement?.style?.setProperty("--kap-accent", stableColor(path || "Knowledge Atlas"));
    this.renderGraph();
    for (const button of this.domainRail.querySelectorAll(".kap-domain")) {
      button.classList.toggle("is-active", button.textContent.startsWith(`${this.model.folders.get(path)?.name || "\0"} ·`));
    }
  }

  updateInspector(node) {
    this.selectedNode = node;
    const folder = this.currentFocus ? this.model.folders.get(this.currentFocus) : null;
    this.inspectTitle.textContent = node?.label || folder?.name || this.copy.title;
    this.inspectMeta.textContent = node?.detail || this.copy.inspectHint;
    this.inspectAction.classList.toggle("is-visible", node?.type === "note");
  }

  async openNote(path) {
    const file = this.app.vault.getAbstractFileByPath(path);
    if (!(file instanceof TFile)) return;
    const leaf = this.app.workspace.getLeaf(this.plugin.settings.openNotesInNewLeaf);
    await leaf.openFile(file);
  }

  runSearch() {
    const query = this.searchInput.value.trim().toLocaleLowerCase();
    this.searchResults.replaceChildren();
    if (!query) {
      this.searchResults.classList.remove("is-open");
      return;
    }
    const matches = this.model.files
      .map(file => {
        const name = file.basename.toLocaleLowerCase();
        const path = file.path.toLocaleLowerCase();
        const score = name === query ? 0 : name.startsWith(query) ? 1 : name.includes(query) ? 2 : path.includes(query) ? 3 : 99;
        return { file, score };
      })
      .filter(item => item.score < 99)
      .sort((a, b) => a.score - b.score || b.file.stat.mtime - a.file.stat.mtime)
      .slice(0, 10);
    if (!matches.length) createElement(this.searchResults, "div", "kap-search-empty", this.copy.noResults);
    for (const { file } of matches) {
      const button = createButton(this.searchResults, "kap-result", file.basename);
      button.replaceChildren();
      const dot = createElement(button, "span", "kap-result-dot");
      dot.style.setProperty("--kap-result-color", stableColor(file.path));
      const copy = createElement(button, "span", "kap-result-copy");
      createElement(copy, "span", "kap-result-title", file.basename);
      createElement(copy, "span", "kap-result-path", file.parent?.path || this.copy.rootNotes);
      createElement(button, "span", "kap-result-date", formatDate(file.stat.mtime));
      button.addEventListener("click", () => this.openNote(file.path));
    }
    this.searchResults.classList.add("is-open");
  }

  createZoomControls() {
    const controls = createElement(this.stage, "div", "kap-zoom");
    this.zoomOutButton = createButton(controls, "kap-zoom-button", "−", "Zoom out");
    this.zoomValue = createElement(controls, "div", "kap-zoom-value", "100%");
    this.zoomInButton = createButton(controls, "kap-zoom-button", "+", "Zoom in");
    this.zoomResetButton = createButton(controls, "kap-zoom-button is-fit", this.isChinese ? "适配" : "Fit", "Fit graph");
  }

  applyViewTransform() {
    if (this.viewport) {
      const { x, y, k } = this.viewTransform;
      this.viewport.setAttribute("transform", `matrix(${k} 0 0 ${k} ${x} ${y})`);
    }
    if (this.zoomValue) this.zoomValue.textContent = `${Math.round(this.viewTransform.k * 100)}%`;
  }

  resetView(apply = true) {
    this.viewTransform = { x: 0, y: 0, k: 1 };
    if (apply) this.applyViewTransform();
  }

  clientToGraphPoint(event) {
    const matrix = this.graph.getScreenCTM();
    if (matrix) {
      const point = this.graph.createSVGPoint();
      point.x = event.clientX;
      point.y = event.clientY;
      const local = point.matrixTransform(matrix.inverse());
      return { x: local.x, y: local.y };
    }
    const rect = this.graph.getBoundingClientRect();
    return {
      x: (event.clientX - rect.left) * (1200 / Math.max(rect.width, 1)),
      y: (event.clientY - rect.top) * (680 / Math.max(rect.height, 1))
    };
  }

  zoomAt(factor, point = { x: 600, y: 340 }) {
    const previous = this.viewTransform.k;
    const next = clamp(previous * factor, .55, 3);
    if (Math.abs(next - previous) < .001) return;
    this.viewTransform.x = point.x - (point.x - this.viewTransform.x) * (next / previous);
    this.viewTransform.y = point.y - (point.y - this.viewTransform.y) * (next / previous);
    this.viewTransform.k = next;
    this.applyViewTransform();
  }

  bindControls() {
    this.rootElement = this.contentEl.querySelector(".kap-root");
    this.backButton.addEventListener("click", () => this.setFocus(this.model.folders.get(this.currentFocus)?.parent || ""));
    this.overviewButton.addEventListener("click", () => this.setFocus(""));
    this.orbitButton.addEventListener("click", () => {
      this.currentLayout = "radial";
      this.resetView(false);
      this.orbitButton.classList.add("is-active");
      this.treeButton.classList.remove("is-active");
      this.renderGraph();
    });
    this.treeButton.addEventListener("click", () => {
      this.currentLayout = "tree";
      this.resetView(false);
      this.treeButton.classList.add("is-active");
      this.orbitButton.classList.remove("is-active");
      this.renderGraph();
    });
    this.refreshButton.addEventListener("click", () => this.render());
    this.inspectAction.addEventListener("click", () => {
      if (this.selectedNode?.type === "note") this.openNote(this.selectedNode.path);
    });
    this.searchInput.addEventListener("input", () => this.runSearch());
    this.searchInput.addEventListener("keydown", event => {
      if (event.key === "Escape") {
        this.searchInput.value = "";
        this.runSearch();
        this.searchInput.blur();
      }
    });
    this.searchInput.closest(".kap-search-wrap").addEventListener("focusout", () => {
      window.setTimeout(() => {
        if (!this.searchInput.closest(".kap-search-wrap").contains(document.activeElement)) this.searchResults.classList.remove("is-open");
      }, 0);
    });
    this.zoomOutButton.addEventListener("click", () => this.zoomAt(1 / 1.22));
    this.zoomInButton.addEventListener("click", () => this.zoomAt(1.22));
    this.zoomResetButton.addEventListener("click", () => this.resetView());
    this.graph.addEventListener("wheel", event => {
      event.preventDefault();
      this.zoomAt(event.deltaY < 0 ? 1.14 : 1 / 1.14, this.clientToGraphPoint(event));
    }, { passive: false });
    this.graph.addEventListener("pointerdown", event => {
      if (event.button !== 0 || event.target.closest?.(".kap-node")) return;
      const point = this.clientToGraphPoint(event);
      this.panState = { pointerId: event.pointerId, startX: point.x, startY: point.y, originX: this.viewTransform.x, originY: this.viewTransform.y };
      this.graph.setPointerCapture(event.pointerId);
      this.graph.classList.add("is-panning");
    });
    this.graph.addEventListener("pointermove", event => {
      if (!this.panState || event.pointerId !== this.panState.pointerId) return;
      const point = this.clientToGraphPoint(event);
      this.viewTransform.x = this.panState.originX + point.x - this.panState.startX;
      this.viewTransform.y = this.panState.originY + point.y - this.panState.startY;
      this.applyViewTransform();
    });
    const stopPan = event => {
      if (!this.panState || event.pointerId !== this.panState.pointerId) return;
      if (this.graph.hasPointerCapture(event.pointerId)) this.graph.releasePointerCapture(event.pointerId);
      this.panState = null;
      this.graph.classList.remove("is-panning");
    };
    this.graph.addEventListener("pointerup", stopPan);
    this.graph.addEventListener("pointercancel", stopPan);
    this.graph.addEventListener("dblclick", event => {
      if (!event.target.closest?.(".kap-node")) this.resetView();
    });
  }
}

class KnowledgeAtlasSettingTab extends PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }

  display() {
    const { containerEl } = this;
    containerEl.empty();
    new Setting(containerEl)
      .setName("Excluded folders")
      .setDesc("Comma-separated folder paths or prefixes that should not appear in the atlas.")
      .addText(text => text
        .setPlaceholder(".obsidian, .trash, Templates, assets")
        .setValue(this.plugin.settings.excludedFolders.join(", "))
        .onChange(async value => {
          this.plugin.settings.excludedFolders = value.split(",").map(item => item.trim()).filter(Boolean);
          await this.plugin.saveSettings();
        }));
    new Setting(containerEl)
      .setName("Maximum folders")
      .setDesc("Maximum folder nodes drawn in one level.")
      .addSlider(slider => slider.setLimits(8, 80, 4).setValue(this.plugin.settings.maxFolders).setDynamicTooltip().onChange(async value => {
        this.plugin.settings.maxFolders = value;
        await this.plugin.saveSettings();
      }));
    new Setting(containerEl)
      .setName("Maximum notes")
      .setDesc("Maximum note nodes drawn in one level.")
      .addSlider(slider => slider.setLimits(12, 120, 6).setValue(this.plugin.settings.maxNotes).setDynamicTooltip().onChange(async value => {
        this.plugin.settings.maxNotes = value;
        await this.plugin.saveSettings();
      }));
    new Setting(containerEl)
      .setName("Recent notes")
      .setDesc("Number of recently modified notes shown in the side panel.")
      .addSlider(slider => slider.setLimits(3, 20, 1).setValue(this.plugin.settings.recentLimit).setDynamicTooltip().onChange(async value => {
        this.plugin.settings.recentLimit = value;
        await this.plugin.saveSettings();
      }));
    new Setting(containerEl)
      .setName("Open notes in a new tab")
      .setDesc("Keep the atlas open when a note node is selected.")
      .addToggle(toggle => toggle.setValue(this.plugin.settings.openNotesInNewLeaf).onChange(async value => {
        this.plugin.settings.openNotesInNewLeaf = value;
        await this.plugin.saveSettings();
      }));
  }
}

module.exports = class KnowledgeAtlasPlugin extends Plugin {
  async onload() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
    addIcon(ICON_ID, ICON_SVG);
    this.registerView(VIEW_TYPE, leaf => new KnowledgeAtlasView(leaf, this));
    this.addRibbonIcon(ICON_ID, "Open Knowledge Atlas", () => this.activateView());
    this.addCommand({ id: "open-knowledge-atlas", name: "Open Knowledge Atlas", callback: () => this.activateView() });
    this.addCommand({ id: "refresh-knowledge-atlas", name: "Refresh Knowledge Atlas", callback: () => this.refreshViews() });
    this.addSettingTab(new KnowledgeAtlasSettingTab(this.app, this));
    ["create", "delete", "rename", "modify"].forEach(eventName => {
      this.registerEvent(this.app.vault.on(eventName, () => this.queueRefresh()));
    });
    this.registerEvent(this.app.metadataCache.on("resolved", () => this.queueRefresh()));
  }

  onunload() {
    if (this.refreshTimer) window.clearTimeout(this.refreshTimer);
    this.app.workspace.detachLeavesOfType(VIEW_TYPE);
  }

  async activateView() {
    let leaf = this.app.workspace.getLeavesOfType(VIEW_TYPE)[0];
    if (!leaf) {
      leaf = this.app.workspace.getLeaf(true);
      await leaf.setViewState({ type: VIEW_TYPE, active: true });
    }
    this.app.workspace.revealLeaf(leaf);
  }

  queueRefresh() {
    if (this.refreshTimer) window.clearTimeout(this.refreshTimer);
    this.refreshTimer = window.setTimeout(() => this.refreshViews(), 800);
  }

  refreshViews() {
    for (const leaf of this.app.workspace.getLeavesOfType(VIEW_TYPE)) {
      if (leaf.view instanceof KnowledgeAtlasView) leaf.view.render();
    }
  }

  async saveSettings() {
    await this.saveData(this.settings);
    this.refreshViews();
  }
};
