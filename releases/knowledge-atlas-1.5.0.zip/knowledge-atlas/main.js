const {
  addIcon,
  getAllTags,
  ItemView,
  Plugin,
  PluginSettingTab,
  Setting,
  TFile
} = require("obsidian");

const VIEW_TYPE = "knowledge-atlas-view";
const ROOT_NOTES = "@root-notes";
const SVG_NS = "http://www.w3.org/2000/svg";
const GRAPH_WIDTH = 1200;
const GRAPH_HEIGHT = 1080;
const GRAPH_CENTER_X = GRAPH_WIDTH / 2;
const GRAPH_CENTER_Y = GRAPH_HEIGHT / 2;
const ICON_ID = "knowledge-atlas-orbit";
const ICON_SVG = `
  <ellipse cx="50" cy="50" rx="42" ry="19" fill="none" stroke="currentColor" stroke-width="6" />
  <ellipse cx="50" cy="50" rx="19" ry="42" fill="none" stroke="currentColor" stroke-width="6" transform="rotate(-35 50 50)" />
  <circle cx="50" cy="50" r="9" fill="currentColor" stroke="none" />
  <circle cx="88" cy="44" r="6" fill="currentColor" stroke="none" />
  <circle cx="33" cy="17" r="5" fill="currentColor" stroke="none" />
`;
const PALETTE = ["#22d3ee", "#5b8cff", "#a855f7", "#f43f8e", "#ff8a34", "#34d399", "#facc15", "#fb7185"];
const DEFAULT_SETTINGS = {
  excludedFolders: [".obsidian", ".trash", "Templates", "assets"],
  maxFolders: 48,
  maxNotes: 54,
  sampleNotes: 18,
  recentLimit: 8,
  openNotesInNewLeaf: false,
  language: "auto",
  openOnStartup: true,
  staleDays: 180,
  dashboardLayout: null
};

const COPY = {
  en: {
    kicker: "VAULT / KNOWLEDGE ATLAS",
    title: "Knowledge Atlas",
    subtitle: "Explore folders, notes, and the links between them.",
    notes: "notes",
    folders: "folders",
    links: "links",
    search: "Search every note…",
    back: "← Back",
    overview: "⌂ Overview",
    orbit: "Galaxy",
    tree: "Tree",
    refresh: "Refresh",
    layoutEdit: "Arrange layout",
    layoutDone: "Done",
    layoutReset: "Reset",
    layoutHint: "Drag the upper-left handle to move · drag the lower-right corner to resize",
    moveItem: "Move",
    resizeItem: "Resize",
    canvas: "Galaxy canvas",
    readGraph: "How to read",
    folder: "Folder / drill down",
    note: "Note / open",
    noteLink: "Note link",
    sample: "Recent sample",
    star: "Star / vault",
    planet: "Planet / top-level folder",
    moon: "Moon / second-level folder",
    comet: "Comet / root AGENTS.md",
    recent: "Recently updated",
    collapsed: "The galaxy shows the vault, top-level planets, and second-level moons.",
    complete: "All nodes in this level are visible. Dashed lines are real note links.",
    moreFolders: "more folders",
    moreNotes: "more notes",
    hiddenHint: "Continue drilling down or use search.",
    noResults: "No matching notes. Try a title or folder name.",
    noNotes: "No Markdown notes are available with the current exclusions.",
    orbitHint: "Galaxy · wheel to zoom · drag to pan",
    treeHint: "Tree · wheel to zoom · drag to pan",
    rootNotes: "Root notes",
    vault: "VAULT",
    graphLabel: "Interactive knowledge atlas",
    language: "Language",
    languageAuto: "Auto",
    languageChinese: "中文",
    languageEnglish: "English",
    fit: "Fit",
    zoomOut: "Zoom out",
    zoomIn: "Zoom in",
    heatmapTitle: "Growth heatmap",
    heatmapMeta: "last 53 weeks",
    less: "Less",
    more: "More",
    notesCreated: "notes created",
    trajectoryTitle: "Growth trajectory",
    trajectoryMeta: "Based on note creation time",
    annualRhythm: "The year in motion",
    weeklyRhythm: "Rhythm of the week",
    clockTitle: "Clock",
    clockKicker: "NOW / LOCAL TIME",
    calendarTitle: "Calendar",
    previousMonth: "Previous month",
    nextMonth: "Next month",
    goodMorning: "Good morning",
    goodAfternoon: "Good afternoon",
    goodEvening: "Good evening",
    goodNight: "Good night",
    today: "Today",
    settingsLanguage: "Interface language",
    settingsLanguageDesc: "Choose a language for the atlas, or follow Obsidian's system language.",
    settingsStartup: "Open Atlas on startup",
    settingsStartupDesc: "Open Knowledge Atlas after the Obsidian workspace is ready.",
    settingsExcluded: "Excluded folders",
    settingsExcludedDesc: "Comma-separated folder paths or prefixes that should not appear in the atlas.",
    settingsMaxFolders: "Maximum folders",
    settingsMaxFoldersDesc: "Maximum folder nodes drawn in one level.",
    settingsMaxNotes: "Maximum notes",
    settingsMaxNotesDesc: "Maximum note nodes drawn in one level.",
    settingsRecent: "Recent notes",
    settingsRecentDesc: "Number of recently modified notes shown in the side panel.",
    settingsNewTab: "Open notes in a new tab",
    settingsNewTabDesc: "Keep the atlas open when a note node is selected.",
    settingsStaleDays: "Stale note threshold",
    settingsStaleDaysDesc: "A note is considered stale after this many days without an update.",
    allFolders: "All folders",
    allTags: "All tags",
    last30Days: "Last 30 days",
    last90Days: "Last 90 days",
    lastYear: "Last year",
    allTime: "All time",
    filterFolder: "Filter by folder",
    filterTag: "Filter by tag",
    filterRange: "Filter by time range",
    healthKicker: "KNOWLEDGE HEALTH",
    healthTitle: "Health and review",
    orphanNotes: "Orphan notes",
    brokenLinks: "Broken links",
    staleNotes: "Stale notes",
    healthEmpty: "No notes in this category.",
    brokenTargets: "broken targets",
    staleFor: "days quiet",
    dailyReview: "Daily review",
    dailyReviewHint: "Three older notes, refreshed each day.",
    createdOn: "Created on",
    dayEmpty: "No notes were created on this day.",
    showDayNotes: "Show notes created on this day",
    moreDayNotes: "more notes · use filters to narrow the list",
    moreHealthNotes: "more notes · use search to continue"
  },
  zh: {
    kicker: "知识库 / KNOWLEDGE ATLAS",
    title: "知识星图",
    subtitle: "沿目录浏览笔记，并发现它们之间的真实双链。",
    notes: "笔记",
    folders: "目录",
    links: "链接",
    search: "搜索全部笔记…",
    back: "← 返回",
    overview: "⌂ 总览",
    orbit: "星系",
    tree: "树状",
    refresh: "刷新",
    layoutEdit: "调整布局",
    layoutDone: "完成",
    layoutReset: "重置",
    layoutHint: "拖动左上角手柄移动 · 拖动右下角缩放",
    moveItem: "移动",
    resizeItem: "调整大小",
    canvas: "星系画布",
    readGraph: "读图方式",
    folder: "目录 / 下钻",
    note: "笔记 / 打开",
    noteLink: "双链关系",
    sample: "最近采样",
    star: "恒星 / Vault",
    planet: "行星 / 一级目录",
    moon: "卫星 / 二级目录",
    comet: "彗星 / 根目录 AGENTS.md",
    recent: "最近更新",
    collapsed: "总览显示 Vault 恒星、一级目录行星与二级目录卫星。",
    complete: "当前层级节点已完整显示；虚线表示真实双链。",
    moreFolders: "个目录未绘制",
    moreNotes: "篇笔记未绘制",
    hiddenHint: "可继续下钻或使用搜索。",
    noResults: "没有找到匹配笔记，可尝试标题或目录名称。",
    noNotes: "按当前排除规则，没有可显示的 Markdown 笔记。",
    orbitHint: "星系 · 滚轮缩放 · 拖动画布",
    treeHint: "树状 · 滚轮缩放 · 拖动画布",
    rootNotes: "根目录笔记",
    vault: "知识库",
    graphLabel: "交互式知识星图",
    language: "语言",
    languageAuto: "跟随系统",
    languageChinese: "中文",
    languageEnglish: "English",
    fit: "适配",
    zoomOut: "缩小",
    zoomIn: "放大",
    heatmapTitle: "年度增长热力图",
    heatmapMeta: "最近 53 周",
    less: "少",
    more: "多",
    notesCreated: "篇新增笔记",
    trajectoryTitle: "增长轨迹",
    trajectoryMeta: "按笔记创建时间统计",
    annualRhythm: "这一年的起伏轨迹",
    weeklyRhythm: "一周里的节奏",
    clockTitle: "时钟",
    clockKicker: "此刻 / 本地时间",
    calendarTitle: "日历",
    previousMonth: "上个月",
    nextMonth: "下个月",
    goodMorning: "早上好",
    goodAfternoon: "下午好",
    goodEvening: "晚上好",
    goodNight: "夜深了",
    today: "今天",
    settingsLanguage: "界面语言",
    settingsLanguageDesc: "选择星图界面语言，或跟随 Obsidian 的系统语言。",
    settingsStartup: "启动时打开知识星图",
    settingsStartupDesc: "Obsidian 工作区加载完成后自动打开 Knowledge Atlas。",
    settingsExcluded: "排除目录",
    settingsExcludedDesc: "以英文逗号分隔，不在星图中显示的目录路径或前缀。",
    settingsMaxFolders: "目录节点上限",
    settingsMaxFoldersDesc: "单个层级最多绘制的目录节点数量。",
    settingsMaxNotes: "笔记节点上限",
    settingsMaxNotesDesc: "单个层级最多绘制的笔记节点数量。",
    settingsRecent: "最近笔记数量",
    settingsRecentDesc: "右侧面板显示的最近修改笔记数量。",
    settingsNewTab: "在新标签页打开笔记",
    settingsNewTabDesc: "打开笔记节点时保留知识星图。",
    settingsStaleDays: "长期未更新阈值",
    settingsStaleDaysDesc: "超过该天数未修改的笔记会被标记为长期未更新。",
    allFolders: "全部目录",
    allTags: "全部标签",
    last30Days: "最近 30 天",
    last90Days: "最近 90 天",
    lastYear: "最近一年",
    allTime: "全部时间",
    filterFolder: "按目录过滤",
    filterTag: "按标签过滤",
    filterRange: "按时间范围过滤",
    healthKicker: "知识健康",
    healthTitle: "知识健康与回顾",
    orphanNotes: "孤立笔记",
    brokenLinks: "断链",
    staleNotes: "长期未更新",
    healthEmpty: "这个分类中没有笔记。",
    brokenTargets: "个断链目标",
    staleFor: "天未更新",
    dailyReview: "每日回顾",
    dailyReviewHint: "每天固定随机挑选 3 篇较旧笔记。",
    createdOn: "创建于",
    dayEmpty: "当天没有新增笔记。",
    showDayNotes: "查看当天新增笔记",
    moreDayNotes: "篇未展开 · 可使用筛选器缩小范围",
    moreHealthNotes: "篇未展开 · 可继续使用全库搜索"
  }
};

function createElement(parent, tag, className, text) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (text !== undefined) element.textContent = text;
  parent.appendChild(element);
  return element;
}

function createButton(parent, className, text, label) {
  const button = createElement(parent, "button", className, text);
  button.type = "button";
  if (label) button.setAttribute("aria-label", label);
  return button;
}

function createSvg(tag, attributes = {}) {
  const element = document.createElementNS(SVG_NS, tag);
  for (const [key, value] of Object.entries(attributes)) element.setAttribute(key, String(value));
  return element;
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function snap(value, step = 8) {
  return Math.round(value / step) * step;
}

function shortLabel(value, length = 20) {
  const text = String(value || "");
  return text.length > length ? `${text.slice(0, length - 1)}…` : text;
}

function topLevel(path) {
  return String(path || "").split("/")[0] || ROOT_NOTES;
}

function stableColor(path) {
  const value = topLevel(path);
  let hash = 0;
  for (let index = 0; index < value.length; index += 1) hash = ((hash << 5) - hash + value.charCodeAt(index)) | 0;
  return PALETTE[Math.abs(hash) % PALETTE.length];
}

function resolveLanguage(setting = "auto") {
  if (setting === "zh" || setting === "en") return setting;
  return (navigator.language || "en").toLowerCase().startsWith("zh") ? "zh" : "en";
}

function dayKey(value) {
  const date = value instanceof Date ? value : new Date(value);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function addDays(value, amount) {
  const date = new Date(value);
  date.setDate(date.getDate() + amount);
  return date;
}

function startOfWeek(value, firstDay = 1) {
  const date = new Date(value);
  date.setHours(0, 0, 0, 0);
  const offset = (date.getDay() - firstDay + 7) % 7;
  date.setDate(date.getDate() - offset);
  return date;
}

function sameDay(left, right) {
  return dayKey(left) === dayKey(right);
}

function parseTimestamp(value, fallback) {
  if (value instanceof Date && !Number.isNaN(value.getTime())) return value.getTime();
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && !value.includes("{{")) {
    const parsed = Date.parse(value);
    if (!Number.isNaN(parsed)) return parsed;
  }
  return fallback;
}

function deterministicScore(value) {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

function normalizeTag(value) {
  const tag = String(value || "").trim().replace(/^#/, "");
  if (
    !tag ||
    tag.length > 80 ||
    /-{3,}/.test(tag) ||
    tag.endsWith("/") ||
    !/\p{L}/u.test(tag) ||
    !/^[\p{L}_][\p{L}\p{N}_/-]*$/u.test(tag) ||
    /^[0-9a-f]{3,8}$/i.test(tag)
  ) return "";
  return tag.toLocaleLowerCase();
}

function formatDate(timestamp, includeTime = false, locale) {
  if (!timestamp) return "";
  const date = new Date(timestamp);
  const options = includeTime
    ? { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" }
    : { month: "2-digit", day: "2-digit" };
  return new Intl.DateTimeFormat(locale, options).format(date);
}

class KnowledgeAtlasView extends ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.plugin = plugin;
    this.currentFocus = "";
    this.currentLayout = "radial";
    this.viewport = null;
    this.viewTransform = { x: 0, y: 0, k: 1 };
    this.panState = null;
    this.clockTimer = null;
    this.calendarCursor = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
    this.activityFilters = { folder: "", tag: "", range: "365" };
    this.activeHealthType = "orphan";
    this.selectedActivityDay = "";
    this.layoutEditing = false;
    this.layoutItems = [];
    this.layoutZCounter = 20;
    this.layoutResizeObserver = null;
    this.layoutFrame = null;
    this.layoutAppliedWidth = 0;
    this.applyLanguage();
  }

  applyLanguage() {
    this.language = resolveLanguage(this.plugin.settings.language);
    this.isChinese = this.language === "zh";
    this.locale = this.isChinese ? "zh-CN" : "en-US";
    this.copy = COPY[this.language];
  }

  getViewType() {
    return VIEW_TYPE;
  }

  getDisplayText() {
    return this.copy.title;
  }

  getIcon() {
    return ICON_ID;
  }

  async onOpen() {
    this.render();
  }

  async onClose() {
    if (this.clockTimer) window.clearInterval(this.clockTimer);
    if (this.layoutFrame) window.cancelAnimationFrame(this.layoutFrame);
    this.layoutResizeObserver?.disconnect();
  }

  isExcluded(path) {
    return this.plugin.settings.excludedFolders.some(prefix => path === prefix || path.startsWith(`${prefix}/`));
  }

  buildModel() {
    const allMarkdownFiles = this.app.vault.getMarkdownFiles();
    const cometFile = allMarkdownFiles.find(file => (!file.parent?.path || file.parent.path === "/") && file.basename.toLowerCase() === "agents") || null;
    const files = allMarkdownFiles.filter(file => !this.isExcluded(file.path));
    const folders = new Map();

    const ensureFolder = (path, displayName) => {
      if (!folders.has(path)) {
        const parts = path === ROOT_NOTES ? [] : path.split("/");
        folders.set(path, {
          path,
          name: displayName || parts.at(-1) || this.copy.rootNotes,
          parent: path === ROOT_NOTES || parts.length <= 1 ? "" : parts.slice(0, -1).join("/"),
          children: new Set(),
          files: [],
          count: 0
        });
      }
      return folders.get(path);
    };

    for (const file of files) {
      const folderPath = file.parent?.path || "";
      if (!folderPath || folderPath === "/") {
        const root = ensureFolder(ROOT_NOTES, this.copy.rootNotes);
        root.files.push(file);
        root.count += 1;
        continue;
      }
      const parts = folderPath.split("/").filter(Boolean);
      for (let index = 0; index < parts.length; index += 1) {
        const path = parts.slice(0, index + 1).join("/");
        const folder = ensureFolder(path);
        folder.count += 1;
        if (index > 0) ensureFolder(parts.slice(0, index).join("/")).children.add(path);
      }
      ensureFolder(folderPath).files.push(file);
    }

    const roots = [...folders.values()]
      .filter(folder => folder.parent === "")
      .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
    let linkCount = 0;
    const filePaths = new Set(files.map(file => file.path));
    const incomingByPath = new Map(files.map(file => [file.path, 0]));
    const outgoingByPath = new Map();
    const brokenByPath = new Map();
    const tagsByPath = new Map();
    const allTags = new Set();
    const tagCounts = new Map();
    for (const file of files) {
      const cache = this.app.metadataCache.getFileCache(file);
      const tags = new Set(((cache && getAllTags(cache)) || []).map(normalizeTag).filter(Boolean));
      tagsByPath.set(file.path, tags);
      for (const tag of tags) {
        allTags.add(tag);
        tagCounts.set(tag, (tagCounts.get(tag) || 0) + 1);
      }

      const resolved = this.app.metadataCache.resolvedLinks[file.path] || {};
      linkCount += Object.values(resolved).reduce((sum, count) => sum + Number(count || 0), 0);
      const targets = Object.keys(resolved);
      outgoingByPath.set(file.path, targets.length);
      for (const target of targets) {
        if (filePaths.has(target)) incomingByPath.set(target, (incomingByPath.get(target) || 0) + 1);
      }

      const unresolved = this.app.metadataCache.unresolvedLinks[file.path] || {};
      const brokenTargets = Object.entries(unresolved)
        .map(([target, count]) => ({ target, count: Number(count || 0) }))
        .filter(item => item.count > 0);
      if (brokenTargets.length) brokenByPath.set(file.path, brokenTargets);
    }
    const createdByDay = new Map();
    const createdAtByPath = new Map();
    for (const file of files) {
      const frontmatter = this.app.metadataCache.getFileCache(file)?.frontmatter;
      const createdAt = parseTimestamp(frontmatter?.created ?? frontmatter?.created_at ?? frontmatter?.["date-created"], file.stat.ctime);
      createdAtByPath.set(file.path, createdAt);
      const key = dayKey(createdAt);
      if (!createdByDay.has(key)) createdByDay.set(key, []);
      createdByDay.get(key).push(file);
    }
    const orphanNotes = files
      .filter(file => (incomingByPath.get(file.path) || 0) === 0 && (outgoingByPath.get(file.path) || 0) === 0)
      .sort((a, b) => b.stat.mtime - a.stat.mtime);
    const brokenNotes = [...brokenByPath.entries()]
      .map(([path, targets]) => ({ file: this.app.vault.getAbstractFileByPath(path), targets, count: targets.reduce((sum, item) => sum + item.count, 0) }))
      .filter(item => item.file instanceof TFile)
      .sort((a, b) => b.count - a.count || a.file.path.localeCompare(b.file.path));
    const staleCutoff = Date.now() - this.plugin.settings.staleDays * 86400000;
    const staleNotes = files.filter(file => file.stat.mtime < staleCutoff).sort((a, b) => a.stat.mtime - b.stat.mtime);
    return {
      files,
      folders,
      roots,
      linkCount,
      createdByDay,
      createdAtByPath,
      tagsByPath,
      allTags: [...allTags]
        .filter(tag => (tagCounts.get(tag) || 0) >= 2)
        .sort((a, b) => (tagCounts.get(b) || 0) - (tagCounts.get(a) || 0) || a.localeCompare(b))
        .slice(0, 120),
      tagCounts,
      cometFile,
      health: { orphanNotes, brokenNotes, staleNotes }
    };
  }

  render() {
    if (this.clockTimer) window.clearInterval(this.clockTimer);
    if (this.layoutFrame) window.cancelAnimationFrame(this.layoutFrame);
    this.layoutResizeObserver?.disconnect();
    this.clockTimer = null;
    this.layoutFrame = null;
    this.layoutEditing = false;
    this.layoutItems = [];
    this.applyLanguage();
    this.contentEl.empty();
    this.contentEl.addClass("knowledge-atlas-plugin-view");
    this.model = this.buildModel();
    if (this.currentFocus && !this.model.folders.has(this.currentFocus)) this.currentFocus = "";

    const root = createElement(this.contentEl, "div", "kap-root");
    const header = createElement(root, "header", "kap-header");
    const titleWrap = createElement(header, "div", "kap-title-wrap");
    createElement(titleWrap, "div", "kap-kicker", this.copy.kicker);
    createElement(titleWrap, "h1", "kap-title", this.copy.title);
    createElement(titleWrap, "p", "kap-subtitle", this.copy.subtitle);
    const stats = createElement(header, "div", "kap-stats");
    [[this.model.files.length, this.copy.notes], [this.model.folders.size, this.copy.folders], [this.model.linkCount, this.copy.links]].forEach(([value, label]) => {
      const item = createElement(stats, "div", "kap-stat");
      createElement(item, "strong", "kap-stat-value", Number(value).toLocaleString(this.locale));
      createElement(item, "span", "kap-stat-label", label);
    });

    const toolbar = createElement(root, "div", "kap-toolbar");
    const searchWrap = createElement(toolbar, "div", "kap-search-wrap");
    const searchIcon = createElement(searchWrap, "span", "kap-search-icon");
    searchIcon.setAttribute("aria-hidden", "true");
    this.searchInput = createElement(searchWrap, "input", "kap-search");
    this.searchInput.type = "search";
    this.searchInput.placeholder = this.copy.search;
    this.searchInput.setAttribute("aria-label", this.copy.search);
    this.searchResults = createElement(searchWrap, "div", "kap-search-results");
    const controls = createElement(toolbar, "div", "kap-controls");
    this.backButton = createButton(controls, "kap-button", this.copy.back);
    this.overviewButton = createButton(controls, "kap-button", this.copy.overview);
    this.orbitButton = createButton(controls, "kap-button is-active", this.copy.orbit);
    this.treeButton = createButton(controls, "kap-button", this.copy.tree);
    this.layoutButton = createButton(controls, "kap-button kap-layout-toggle", this.copy.layoutEdit);
    this.layoutResetButton = createButton(controls, "kap-button kap-layout-reset", this.copy.layoutReset);
    this.refreshButton = createButton(controls, "kap-button", "↻", this.copy.refresh);

    this.domainRail = createElement(root, "div", "kap-domain-rail");
    this.renderDomainRail();

    const body = createElement(root, "div", "kap-body");
    this.body = body;
    this.layoutNotice = createElement(body, "div", "kap-layout-notice", this.copy.layoutHint);
    this.stage = createElement(body, "section", "kap-stage");
    const stageHeader = createElement(this.stage, "div", "kap-stage-header");
    this.breadcrumbs = createElement(stageHeader, "div", "kap-breadcrumbs");
    this.viewHint = createElement(stageHeader, "div", "kap-view-hint");
    this.graph = createSvg("svg", { class: "kap-graph", viewBox: `0 0 ${GRAPH_WIDTH} ${GRAPH_HEIGHT}`, role: "img", "aria-label": this.copy.graphLabel });
    this.stage.appendChild(this.graph);
    this.limitNote = createElement(this.stage, "div", "kap-limit-note");
    this.createZoomControls();

    const dock = createElement(body, "aside", "kap-dock kap-right-rail");
    this.dock = dock;
    const clockPanel = createElement(dock, "section", "kap-insight-panel kap-clock-panel");
    this.renderClock(clockPanel);
    const calendarPanel = createElement(dock, "section", "kap-insight-panel kap-calendar-panel");
    this.renderCalendar(calendarPanel);
    this.heatmapPanel = createElement(dock, "section", "kap-insight-panel kap-heatmap-panel");
    this.renderHeatmap(this.heatmapPanel);
    this.trajectoryPanel = createElement(dock, "section", "kap-insight-panel kap-trajectory-panel");
    this.renderTrajectory(this.trajectoryPanel);
    const healthPanel = createElement(dock, "section", "kap-insight-panel kap-health-panel");
    this.renderHealth(healthPanel);
    const reviewPanel = createElement(dock, "section", "kap-insight-panel kap-review-panel");
    this.renderDailyReview(reviewPanel);

    const legendPanel = createElement(dock, "section", "kap-panel");
    createElement(legendPanel, "h2", "kap-panel-title", this.copy.readGraph);
    const legend = createElement(legendPanel, "div", "kap-legend");
    [["star", this.copy.star, "#f8c86a"], ["planet", this.copy.planet, PALETTE[1]], ["moon", this.copy.moon, PALETTE[0]], ["comet", this.copy.comet, "#f4f0ff"]].forEach(([type, label, color]) => {
      const item = createElement(legend, "div", "kap-legend-item");
      const mark = createElement(item, "span", `kap-legend-mark is-${type}`);
      mark.style.setProperty("--kap-legend-color", color);
      createElement(item, "span", "", label);
    });

    const recentPanel = createElement(dock, "section", "kap-panel kap-recent-panel");
    createElement(recentPanel, "h2", "kap-panel-title", this.copy.recent);
    this.recentList = createElement(recentPanel, "div", "kap-recent-list");
    this.renderRecent();

    this.setupLayoutItems([
      ["canvas", this.stage, this.copy.canvas],
      ["clock", clockPanel, this.copy.clockTitle],
      ["calendar", calendarPanel, this.copy.calendarTitle],
      ["heatmap", this.heatmapPanel, this.copy.heatmapTitle],
      ["trajectory", this.trajectoryPanel, this.copy.trajectoryTitle],
      ["health", healthPanel, this.copy.healthTitle],
      ["review", reviewPanel, this.copy.dailyReview],
      ["legend", legendPanel, this.copy.readGraph],
      ["recent", recentPanel, this.copy.recent]
    ]);

    this.bindControls();

    if (!this.model.files.length) {
      this.graph.replaceWith(createElement(document.createDocumentFragment(), "div", "kap-empty", this.copy.noNotes));
    } else {
      this.setFocus(this.currentFocus || "");
    }
    this.layoutFrame = window.requestAnimationFrame(() => {
      this.layoutFrame = null;
      this.applySavedLayout();
      this.observeLayoutWidth();
    });
  }

  clearPanelContent(panel) {
    for (const child of [...panel.children]) {
      if (!child.classList.contains("kap-layout-handle") && !child.classList.contains("kap-resize-handle")) child.remove();
    }
  }

  setupLayoutItems(entries) {
    this.layoutItems = entries.map(([id, element, label], index) => ({ id, element, label, z: index + 2 }));
    for (const item of this.layoutItems) {
      item.element.classList.add("kap-layout-item");
      item.element.dataset.layoutId = item.id;
      item.element.style.setProperty("--kap-layout-order", String(item.z));
      const move = createElement(item.element, "button", "kap-layout-handle", "⠿");
      move.type = "button";
      move.title = `${this.copy.moveItem} ${item.label}`;
      move.setAttribute("aria-label", move.title);
      const resize = createElement(item.element, "button", "kap-resize-handle", "");
      resize.type = "button";
      resize.title = `${this.copy.resizeItem} ${item.label}`;
      resize.setAttribute("aria-label", resize.title);
      move.addEventListener("pointerdown", event => this.startLayoutInteraction(event, item, "move"));
      resize.addEventListener("pointerdown", event => this.startLayoutInteraction(event, item, "resize"));
    }
  }

  getLayoutMinimum(item) {
    if (item.id === "canvas") return { width: 560, height: 600 };
    if (item.id === "heatmap" || item.id === "trajectory") return { width: 300, height: 260 };
    if (item.id === "health" || item.id === "recent") return { width: 280, height: 240 };
    return { width: 250, height: 150 };
  }

  captureCurrentLayout() {
    if (!this.body || !this.layoutItems.length) return null;
    const bodyRect = this.body.getBoundingClientRect();
    const items = {};
    for (const item of this.layoutItems) {
      const rect = item.element.getBoundingClientRect();
      items[item.id] = {
        x: Math.max(0, rect.left - bodyRect.left),
        y: Math.max(0, rect.top - bodyRect.top),
        width: rect.width,
        height: rect.height,
        z: Number.parseInt(item.element.style.zIndex || item.z, 10) || item.z
      };
    }
    return { viewportWidth: Math.max(this.body.clientWidth, 1), items };
  }

  clearInlineLayout() {
    this.body?.classList.remove("is-free-layout", "is-layout-editing");
    this.body?.style.removeProperty("min-height");
    for (const item of this.layoutItems) {
      for (const property of ["left", "top", "width", "height", "z-index"]) item.element.style.removeProperty(property);
    }
  }

  applySavedLayout() {
    const layout = this.plugin.settings.dashboardLayout;
    const bodyWidth = this.body?.clientWidth || 0;
    if (!layout?.items || !bodyWidth || bodyWidth < 720) {
      this.clearInlineLayout();
      this.layoutAppliedWidth = bodyWidth;
      return;
    }
    this.body.classList.add("is-free-layout");
    const scale = bodyWidth / Math.max(layout.viewportWidth || bodyWidth, 1);
    this.layoutZCounter = 20;
    for (const item of this.layoutItems) {
      const saved = layout.items[item.id];
      if (!saved) continue;
      const minimum = this.getLayoutMinimum(item);
      const width = clamp(saved.width * scale, minimum.width, bodyWidth);
      const height = Math.max(saved.height, minimum.height);
      const left = clamp(saved.x * scale, 0, Math.max(0, bodyWidth - width));
      const top = Math.max(0, saved.y);
      const z = Number(saved.z || item.z);
      item.element.style.left = `${left}px`;
      item.element.style.top = `${top}px`;
      item.element.style.width = `${width}px`;
      item.element.style.height = `${height}px`;
      item.element.style.zIndex = String(z);
      this.layoutZCounter = Math.max(this.layoutZCounter, z);
    }
    this.layoutAppliedWidth = bodyWidth;
    this.updateLayoutHeight();
  }

  updateLayoutHeight() {
    if (!this.body?.classList.contains("is-free-layout")) return;
    const bottom = this.layoutItems.reduce((max, item) => {
      const top = Number.parseFloat(item.element.style.top || 0);
      const height = Number.parseFloat(item.element.style.height || item.element.offsetHeight || 0);
      return Math.max(max, top + height);
    }, 0);
    this.body.style.minHeight = `${Math.ceil(bottom + 24)}px`;
  }

  async persistCurrentLayout() {
    const layout = this.captureCurrentLayout();
    if (!layout) return;
    this.plugin.settings.dashboardLayout = layout;
    await this.plugin.saveSettings(false);
  }

  async setLayoutEditing(enabled) {
    if (!this.body || this.body.clientWidth < 720) return;
    if (enabled && !this.plugin.settings.dashboardLayout?.items) {
      this.plugin.settings.dashboardLayout = this.captureCurrentLayout();
      this.applySavedLayout();
      await this.plugin.saveSettings(false);
    } else if (enabled) this.applySavedLayout();
    this.layoutEditing = enabled;
    this.body.classList.toggle("is-layout-editing", enabled);
    this.layoutButton.classList.toggle("is-active", enabled);
    this.layoutButton.textContent = enabled ? this.copy.layoutDone : this.copy.layoutEdit;
    this.layoutResetButton.classList.toggle("is-visible", enabled);
    if (!enabled) await this.persistCurrentLayout();
  }

  async resetDashboardLayout() {
    this.plugin.settings.dashboardLayout = null;
    await this.plugin.saveSettings(false);
    this.render();
  }

  startLayoutInteraction(event, item, mode) {
    if (!this.layoutEditing || event.button !== 0) return;
    event.preventDefault();
    event.stopPropagation();
    const handle = event.currentTarget;
    const bodyRect = this.body.getBoundingClientRect();
    const itemRect = item.element.getBoundingClientRect();
    const origin = {
      x: itemRect.left - bodyRect.left,
      y: itemRect.top - bodyRect.top,
      width: itemRect.width,
      height: itemRect.height
    };
    const minimum = this.getLayoutMinimum(item);
    const startX = event.clientX;
    const startY = event.clientY;
    item.element.style.zIndex = String(++this.layoutZCounter);
    item.element.classList.add("is-layout-interacting");
    try { handle.setPointerCapture?.(event.pointerId); } catch (_) { /* Synthetic events may not own a pointer capture. */ }
    const move = pointerEvent => {
      const dx = pointerEvent.clientX - startX;
      const dy = pointerEvent.clientY - startY;
      if (mode === "move") {
        const left = clamp(snap(origin.x + dx), 0, Math.max(0, this.body.clientWidth - origin.width));
        const top = Math.max(0, snap(origin.y + dy));
        item.element.style.left = `${left}px`;
        item.element.style.top = `${top}px`;
      } else {
        const maxWidth = Math.max(minimum.width, this.body.clientWidth - origin.x);
        item.element.style.width = `${clamp(snap(origin.width + dx), minimum.width, maxWidth)}px`;
        item.element.style.height = `${Math.max(minimum.height, snap(origin.height + dy))}px`;
      }
      this.updateLayoutHeight();
    };
    const finish = async pointerEvent => {
      try {
        if (handle.hasPointerCapture?.(pointerEvent.pointerId)) handle.releasePointerCapture(pointerEvent.pointerId);
      } catch (_) { /* The pointer may already be released. */ }
      handle.removeEventListener("pointermove", move);
      handle.removeEventListener("pointerup", finish);
      handle.removeEventListener("pointercancel", finish);
      item.element.classList.remove("is-layout-interacting");
      await this.persistCurrentLayout();
    };
    handle.addEventListener("pointermove", move);
    handle.addEventListener("pointerup", finish);
    handle.addEventListener("pointercancel", finish);
  }

  observeLayoutWidth() {
    if (typeof ResizeObserver === "undefined" || !this.body) return;
    this.layoutResizeObserver = new ResizeObserver(() => {
      const width = this.body?.clientWidth || 0;
      if (!this.layoutEditing && Math.abs(width - this.layoutAppliedWidth) > 2) this.applySavedLayout();
    });
    this.layoutResizeObserver.observe(this.body);
  }

  createInsightHeader(parent, kicker, title, meta) {
    const header = createElement(parent, "div", "kap-insight-header");
    const copy = createElement(header, "div", "kap-insight-heading");
    if (kicker) createElement(copy, "div", "kap-panel-kicker", kicker);
    createElement(copy, "h2", "kap-insight-title", title);
    if (meta) createElement(header, "div", "kap-insight-meta", meta);
    return header;
  }

  getFilteredActivityFiles() {
    const cutoffDays = this.activityFilters.range === "all" ? 0 : Number(this.activityFilters.range || 365);
    const cutoff = cutoffDays ? Date.now() - cutoffDays * 86400000 : 0;
    return this.model.files.filter(file => {
      if (this.activityFilters.folder && !file.path.startsWith(`${this.activityFilters.folder}/`)) return false;
      if (this.activityFilters.tag && !this.model.tagsByPath.get(file.path)?.has(this.activityFilters.tag)) return false;
      const createdAt = this.model.createdAtByPath.get(file.path) || file.stat.ctime;
      return !cutoff || createdAt >= cutoff;
    });
  }

  renderActivityFilters(parent) {
    const filters = createElement(parent, "div", "kap-activity-filters");
    const addSelect = (label, value, options, onChange) => {
      const select = createElement(filters, "select", "kap-filter-select");
      select.setAttribute("aria-label", label);
      for (const [optionValue, optionLabel] of options) {
        const option = createElement(select, "option", "", optionLabel);
        option.value = optionValue;
      }
      select.value = value;
      select.addEventListener("change", () => onChange(select.value));
      return select;
    };
    addSelect(
      this.copy.filterFolder,
      this.activityFilters.folder,
      [["", this.copy.allFolders], ...this.model.roots.filter(folder => folder.path !== ROOT_NOTES).map(folder => [folder.path, folder.name])],
      value => {
        this.activityFilters.folder = value;
        this.refreshActivityPanels();
      }
    );
    addSelect(
      this.copy.filterTag,
      this.activityFilters.tag,
      [["", this.copy.allTags], ...this.model.allTags.map(tag => [tag, `#${tag} · ${this.model.tagCounts.get(tag)}`])],
      value => {
        this.activityFilters.tag = value;
        this.refreshActivityPanels();
      }
    );
    addSelect(
      this.copy.filterRange,
      this.activityFilters.range,
      [["30", this.copy.last30Days], ["90", this.copy.last90Days], ["365", this.copy.lastYear], ["all", this.copy.allTime]],
      value => {
        this.activityFilters.range = value;
        this.refreshActivityPanels();
      }
    );
  }

  refreshActivityPanels() {
    if (this.heatmapPanel?.isConnected) this.renderHeatmap(this.heatmapPanel);
    if (this.trajectoryPanel?.isConnected) this.renderTrajectory(this.trajectoryPanel);
  }

  renderDayNotes(parent, date, files) {
    parent.replaceChildren();
    parent.classList.add("is-visible");
    const heading = createElement(parent, "div", "kap-day-detail-heading");
    createElement(heading, "strong", "", formatDate(date, false, this.locale));
    createElement(heading, "span", "", `${files.length} ${this.copy.notesCreated}`);
    if (!files.length) {
      createElement(parent, "div", "kap-health-empty", this.copy.dayEmpty);
      return;
    }
    const list = createElement(parent, "div", "kap-compact-note-list");
    const visibleFiles = [...files].sort((a, b) => a.path.localeCompare(b.path)).slice(0, 80);
    for (const file of visibleFiles) {
      const button = createButton(list, "kap-compact-note", "", file.basename);
      createElement(button, "span", "kap-compact-note-title", file.basename);
      createElement(button, "span", "kap-compact-note-meta", file.parent?.path || this.copy.rootNotes);
      button.addEventListener("click", () => this.openNote(file.path));
    }
    if (files.length > visibleFiles.length) {
      createElement(parent, "div", "kap-day-overflow", `+${files.length - visibleFiles.length} ${this.copy.moreDayNotes}`);
    }
  }

  renderHeatmap(panel) {
    this.clearPanelContent(panel);
    const today = new Date();
    const finalWeek = startOfWeek(today, 1);
    const days = Array.from({ length: 53 * 7 }, (_, index) => {
      const week = Math.floor(index / 7);
      const weekday = index % 7;
      return addDays(finalWeek, -week * 7 + weekday);
    });
    const filteredFiles = this.getFilteredActivityFiles();
    const filesByDay = new Map();
    for (const file of filteredFiles) {
      const key = dayKey(this.model.createdAtByPath.get(file.path) || file.stat.ctime);
      if (!filesByDay.has(key)) filesByDay.set(key, []);
      filesByDay.get(key).push(file);
    }
    const total = days.reduce((sum, date) => sum + (filesByDay.get(dayKey(date))?.length || 0), 0);
    this.createInsightHeader(
      panel,
      "",
      this.copy.heatmapTitle,
      `${total.toLocaleString(this.locale)} ${this.copy.notesCreated} · ${this.copy.heatmapMeta}`
    );
    this.renderActivityFilters(panel);

    const viewport = createElement(panel, "div", "kap-heatmap-viewport");
    const months = createElement(viewport, "div", "kap-heatmap-months");
    let lastMonth = "";
    for (let week = 0; week < 53; week += 1) {
      const marker = addDays(finalWeek, -week * 7 + 3);
      const key = `${marker.getFullYear()}-${marker.getMonth()}`;
      if (key === lastMonth) continue;
      lastMonth = key;
      const label = createElement(months, "span", "", new Intl.DateTimeFormat(this.locale, { month: "short" }).format(marker));
      label.style.gridColumn = String(week + 1);
    }

    const grid = createElement(viewport, "div", "kap-heatmap-grid");
    const maxCount = Math.max(1, ...days.map(date => filesByDay.get(dayKey(date))?.length || 0));
    days.forEach((date, index) => {
      const key = dayKey(date);
      const dayFiles = filesByDay.get(key) || [];
      const count = dayFiles.length;
      const level = count ? Math.max(1, Math.ceil((Math.log1p(count) / Math.log1p(maxCount)) * 4)) : 0;
      const cell = createButton(grid, `kap-heat-cell level-${level}${date > today ? " is-future" : ""}${this.selectedActivityDay === key ? " is-selected" : ""}`, "", this.copy.showDayNotes);
      cell.style.gridColumn = String(Math.floor(index / 7) + 1);
      cell.style.gridRow = String((index % 7) + 1);
      cell.setAttribute("aria-label", `${formatDate(date, false, this.locale)} · ${count} ${this.copy.notesCreated}`);
      cell.setAttribute("title", `${formatDate(date, false, this.locale)} · ${count} ${this.copy.notesCreated}`);
      cell.addEventListener("click", () => {
        this.selectedActivityDay = key;
        for (const item of grid.querySelectorAll(".kap-heat-cell")) item.classList.remove("is-selected");
        cell.classList.add("is-selected");
        this.renderDayNotes(dayDetail, date, dayFiles);
      });
    });

    const dayDetail = createElement(panel, "div", "kap-day-detail");
    if (this.selectedActivityDay) {
      const selectedDate = new Date(`${this.selectedActivityDay}T12:00:00`);
      this.renderDayNotes(dayDetail, selectedDate, filesByDay.get(this.selectedActivityDay) || []);
    }

    const legend = createElement(panel, "div", "kap-heat-legend");
    createElement(legend, "span", "", this.copy.less);
    for (let level = 0; level <= 4; level += 1) createElement(legend, "span", `kap-heat-cell level-${level}`);
    createElement(legend, "span", "", this.copy.more);
  }

  renderTrajectory(panel) {
    this.clearPanelContent(panel);
    this.createInsightHeader(panel, "", this.copy.trajectoryTitle, this.copy.trajectoryMeta);
    const charts = createElement(panel, "div", "kap-chart-grid");
    const monthChart = createElement(charts, "section", "kap-chart");
    createElement(monthChart, "h3", "kap-chart-title", this.copy.annualRhythm);
    const monthData = [];
    const now = new Date();
    const filteredFiles = this.getFilteredActivityFiles();
    for (let offset = 0; offset <= 11; offset += 1) {
      const date = new Date(now.getFullYear(), now.getMonth() - offset, 1);
      const count = filteredFiles.filter(file => {
        const created = new Date(this.model.createdAtByPath.get(file.path) || file.stat.ctime);
        return created.getFullYear() === date.getFullYear() && created.getMonth() === date.getMonth();
      }).length;
      monthData.push({ label: new Intl.DateTimeFormat(this.locale, { month: "short" }).format(date), count });
    }
    this.renderBars(monthChart, monthData, "month");

    const weekChart = createElement(charts, "section", "kap-chart");
    createElement(weekChart, "h3", "kap-chart-title", this.copy.weeklyRhythm);
    const weekStart = this.isChinese ? 1 : 0;
    const weekdayFormatter = new Intl.DateTimeFormat(this.locale, { weekday: "short" });
    const weekData = Array.from({ length: 7 }, (_, index) => {
      const day = (weekStart + index) % 7;
      const sample = addDays(startOfWeek(new Date(), weekStart), index);
      return {
        label: weekdayFormatter.format(sample),
        count: filteredFiles.filter(file => new Date(this.model.createdAtByPath.get(file.path) || file.stat.ctime).getDay() === day).length
      };
    });
    this.renderBars(weekChart, weekData, "week");
  }

  renderBars(parent, data, variant) {
    const bars = createElement(parent, "div", `kap-bars kap-bars-${variant}`);
    const max = Math.max(1, ...data.map(item => item.count));
    for (const item of data) {
      const column = createElement(bars, "div", "kap-bar-column");
      createElement(column, "span", "kap-bar-value", item.count.toLocaleString(this.locale));
      const track = createElement(column, "div", "kap-bar-track");
      const fill = createElement(track, "div", "kap-bar-fill");
      fill.style.height = `${item.count ? Math.max(4, (item.count / max) * 100) : 2}%`;
      fill.setAttribute("title", `${item.label} · ${item.count} ${this.copy.notesCreated}`);
      createElement(column, "span", "kap-bar-label", item.label);
    }
  }

  renderHealth(panel) {
    this.createInsightHeader(panel, this.copy.healthKicker, this.copy.healthTitle);
    const metrics = createElement(panel, "div", "kap-health-metrics");
    const definitions = [
      ["orphan", this.copy.orphanNotes, this.model.health.orphanNotes.length],
      ["broken", this.copy.brokenLinks, this.model.health.brokenNotes.reduce((sum, item) => sum + item.count, 0)],
      ["stale", this.copy.staleNotes, this.model.health.staleNotes.length]
    ];
    const list = createElement(panel, "div", "kap-health-list");
    for (const [type, label, count] of definitions) {
      const button = createButton(metrics, `kap-health-metric${this.activeHealthType === type ? " is-active" : ""}`, "", label);
      createElement(button, "strong", "", count.toLocaleString(this.locale));
      createElement(button, "span", "", label);
      button.addEventListener("click", () => {
        this.activeHealthType = type;
        for (const item of metrics.querySelectorAll(".kap-health-metric")) item.classList.remove("is-active");
        button.classList.add("is-active");
        this.renderHealthList(list, type);
      });
    }
    this.renderHealthList(list, this.activeHealthType);
  }

  renderHealthList(parent, type) {
    parent.replaceChildren();
    const source = type === "broken" ? this.model.health.brokenNotes : type === "stale" ? this.model.health.staleNotes : this.model.health.orphanNotes;
    if (!source.length) {
      createElement(parent, "div", "kap-health-empty", this.copy.healthEmpty);
      return;
    }
    const visibleEntries = source.slice(0, 100);
    for (const entry of visibleEntries) {
      const file = type === "broken" ? entry.file : entry;
      const button = createButton(parent, "kap-health-note", "", file.basename);
      createElement(button, "span", "kap-compact-note-title", file.basename);
      let meta = file.parent?.path || this.copy.rootNotes;
      if (type === "broken") {
        const targets = entry.targets.slice(0, 2).map(item => item.target).join(" · ");
        meta = `${entry.count} ${this.copy.brokenTargets}${targets ? ` · ${targets}` : ""}`;
      } else if (type === "stale") {
        const days = Math.max(1, Math.floor((Date.now() - file.stat.mtime) / 86400000));
        meta = `${days} ${this.copy.staleFor} · ${file.parent?.path || this.copy.rootNotes}`;
      }
      createElement(button, "span", "kap-compact-note-meta", meta);
      button.addEventListener("click", () => this.openNote(file.path));
    }
    if (source.length > visibleEntries.length) {
      createElement(parent, "div", "kap-day-overflow", `+${source.length - visibleEntries.length} ${this.copy.moreHealthNotes}`);
    }
  }

  renderDailyReview(panel) {
    this.createInsightHeader(panel, this.copy.healthKicker, this.copy.dailyReview, this.copy.dailyReviewHint);
    const sorted = [...this.model.files].sort((a, b) => a.stat.mtime - b.stat.mtime);
    const poolSize = Math.min(sorted.length, Math.max(3, Math.ceil(sorted.length * .35)));
    const pool = sorted.slice(0, poolSize);
    const seed = dayKey(new Date());
    const selected = pool
      .map(file => ({ file, score: deterministicScore(`${seed}:${file.path}`) }))
      .sort((a, b) => a.score - b.score)
      .slice(0, 3)
      .map(item => item.file);
    const list = createElement(panel, "div", "kap-review-list");
    if (!selected.length) {
      createElement(list, "div", "kap-health-empty", this.copy.healthEmpty);
      return;
    }
    selected.forEach((file, index) => {
      const button = createButton(list, "kap-review-note", "", file.basename);
      createElement(button, "span", "kap-review-index", String(index + 1).padStart(2, "0"));
      const copy = createElement(button, "span", "kap-review-copy");
      createElement(copy, "span", "kap-compact-note-title", file.basename);
      createElement(copy, "span", "kap-compact-note-meta", `${formatDate(file.stat.mtime, false, this.locale)} · ${file.parent?.path || this.copy.rootNotes}`);
      button.addEventListener("click", () => this.openNote(file.path));
    });
  }

  renderClock(panel) {
    createElement(panel, "div", "kap-panel-kicker", this.copy.clockKicker);
    this.clockGreeting = createElement(panel, "div", "kap-clock-greeting");
    this.clockTime = createElement(panel, "time", "kap-clock-time");
    this.clockDate = createElement(panel, "div", "kap-clock-date");
    const update = () => {
      const now = new Date();
      const hour = now.getHours();
      this.clockGreeting.textContent = hour < 6 ? this.copy.goodNight : hour < 12 ? this.copy.goodMorning : hour < 18 ? this.copy.goodAfternoon : this.copy.goodEvening;
      this.clockTime.textContent = new Intl.DateTimeFormat(this.locale, { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }).format(now);
      this.clockTime.dateTime = now.toISOString();
      this.clockDate.textContent = new Intl.DateTimeFormat(this.locale, { year: "numeric", month: "long", day: "numeric", weekday: "long" }).format(now);
    };
    update();
    this.clockTimer = window.setInterval(update, 1000);
  }

  renderCalendar(panel) {
    this.clearPanelContent(panel);
    const heading = createElement(panel, "div", "kap-calendar-heading");
    const titles = createElement(heading, "div", "");
    createElement(titles, "h2", "kap-insight-title", this.copy.calendarTitle);
    const nav = createElement(heading, "div", "kap-calendar-nav");
    const previous = createButton(nav, "kap-calendar-nav-button", "‹", this.copy.previousMonth);
    const next = createButton(nav, "kap-calendar-nav-button", "›", this.copy.nextMonth);

    const monthTitle = createElement(panel, "div", "kap-calendar-month", new Intl.DateTimeFormat(this.locale, { month: "long", year: "numeric" }).format(this.calendarCursor));
    const grid = createElement(panel, "div", "kap-calendar-grid");
    const firstDay = this.isChinese ? 1 : 0;
    const weekdayFormatter = new Intl.DateTimeFormat(this.locale, { weekday: "narrow" });
    const weekStart = startOfWeek(new Date(), firstDay);
    for (let index = 0; index < 7; index += 1) createElement(grid, "span", "kap-calendar-weekday", weekdayFormatter.format(addDays(weekStart, index)));

    const monthStart = new Date(this.calendarCursor.getFullYear(), this.calendarCursor.getMonth(), 1);
    const calendarStart = startOfWeek(monthStart, firstDay);
    const today = new Date();
    for (let index = 0; index < 42; index += 1) {
      const date = addDays(calendarStart, index);
      const count = this.model.createdByDay.get(dayKey(date))?.length || 0;
      const button = createButton(grid, "kap-calendar-day", String(date.getDate()));
      button.classList.toggle("is-outside", date.getMonth() !== this.calendarCursor.getMonth());
      button.classList.toggle("is-today", sameDay(date, today));
      button.classList.toggle("has-activity", count > 0);
      button.setAttribute("title", `${formatDate(date, false, this.locale)} · ${count} ${this.copy.notesCreated}`);
    }
    previous.addEventListener("click", () => {
      this.calendarCursor = new Date(this.calendarCursor.getFullYear(), this.calendarCursor.getMonth() - 1, 1);
      this.renderCalendar(panel);
    });
    next.addEventListener("click", () => {
      this.calendarCursor = new Date(this.calendarCursor.getFullYear(), this.calendarCursor.getMonth() + 1, 1);
      this.renderCalendar(panel);
    });
    monthTitle.setAttribute("aria-live", "polite");
  }

  renderDomainRail() {
    this.domainRail.replaceChildren();
    for (const folder of this.model.roots) {
      const button = createButton(this.domainRail, "kap-domain", `${folder.name} · ${folder.count}`);
      button.style.setProperty("--kap-domain-color", stableColor(folder.path));
      button.addEventListener("click", () => this.setFocus(folder.path));
    }
  }

  renderRecent() {
    this.recentList.replaceChildren();
    [...this.model.files]
      .sort((a, b) => b.stat.mtime - a.stat.mtime)
      .slice(0, this.plugin.settings.recentLimit)
      .forEach(file => {
        const button = createButton(this.recentList, "kap-recent", file.basename);
        button.replaceChildren();
        const bar = createElement(button, "span", "kap-recent-bar");
        bar.style.setProperty("--kap-recent-color", stableColor(file.path));
        const copy = createElement(button, "span", "kap-recent-copy");
        createElement(copy, "span", "kap-recent-title", file.basename);
        createElement(copy, "span", "kap-recent-path", file.parent?.path || this.copy.rootNotes);
        createElement(button, "span", "kap-recent-date", formatDate(file.stat.mtime, false, this.locale));
        button.addEventListener("click", () => this.openNote(file.path));
      });
  }

  getGalaxyOverview() {
    const roots = [...this.model.roots].sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
    const center = {
      id: "center",
      type: "star",
      label: this.copy.vault,
      path: "VAULT",
      color: "#f8c86a",
      radius: clamp(35 + Math.log2(Math.max(this.model.files.length, 2)) * 1.8, 46, 58),
      detail: `${this.model.files.length} ${this.copy.notes} · ${roots.length} ${this.copy.folders}`
    };
    const planets = roots.map(folder => {
      const mass = folder.count + folder.children.size * 6;
      return {
        id: `folder:${folder.path}`,
        type: "planet",
        label: folder.name,
        path: folder.path,
        color: stableColor(folder.path),
        count: folder.count,
        radius: clamp(14 + Math.sqrt(Math.max(mass, 1)) * .82, 19, 40),
        detail: `${folder.count} ${this.copy.notes} · ${folder.children.size} ${this.copy.folders}`
      };
    });
    const childQueues = roots.map(folder => ({
      parent: folder,
      children: [...folder.children]
        .map(path => this.model.folders.get(path))
        .filter(Boolean)
        .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name))
    }));
    const selected = [];
    let round = 0;
    while (selected.length < this.plugin.settings.maxFolders) {
      let added = false;
      for (const queue of childQueues) {
        const folder = queue.children[round];
        if (!folder || selected.length >= this.plugin.settings.maxFolders) continue;
        selected.push({ folder, parent: queue.parent });
        added = true;
      }
      if (!added) break;
      round += 1;
    }
    const moons = selected.map(({ folder, parent }) => {
      const mass = folder.count + folder.children.size * 4;
      return {
        id: `folder:${folder.path}`,
        type: "moon",
        label: folder.name,
        path: folder.path,
        parentId: `folder:${parent.path}`,
        color: stableColor(parent.path),
        count: folder.count,
        radius: clamp(5.5 + Math.sqrt(Math.max(mass, 1)) * .42, 7, 15),
        detail: `${folder.count} ${this.copy.notes} · ${folder.children.size} ${this.copy.folders}`
      };
    });
    const comet = this.model.cometFile ? {
      id: `note:${this.model.cometFile.path}`,
      type: "comet",
      label: this.model.cometFile.name,
      path: this.model.cometFile.path,
      color: "#f4f0ff",
      file: this.model.cometFile,
      radius: 8,
      detail: `${this.copy.rootNotes} · ${formatDate(this.model.cometFile.stat.mtime, true, this.locale)}`
    } : null;
    const edges = [
      ...planets.map(node => ({ source: "center", target: node.id, type: "orbit", color: node.color })),
      ...moons.map(node => ({ source: node.parentId, target: node.id, type: "satellite", color: node.color }))
    ];
    const availableMoonCount = childQueues.reduce((sum, queue) => sum + queue.children.length, 0);
    return {
      overview: true,
      nodes: [center, ...planets, ...moons, ...(comet ? [comet] : [])],
      edges,
      hiddenFolders: Math.max(0, availableMoonCount - moons.length),
      hiddenNotes: 0
    };
  }

  getVisibleGraph() {
    if (!this.currentFocus) return this.getGalaxyOverview();
    const settings = this.plugin.settings;
    const focusFolder = this.currentFocus ? this.model.folders.get(this.currentFocus) : null;
    const center = {
      id: "center",
      type: "center",
      label: focusFolder?.name || this.copy.vault,
      path: this.currentFocus || "VAULT",
      color: stableColor(this.currentFocus || "Knowledge Atlas"),
      detail: focusFolder
        ? `${focusFolder.count} ${this.copy.notes} · ${focusFolder.children.size} ${this.copy.folders}`
        : `${this.model.files.length} ${this.copy.notes} · ${this.model.roots.length} ${this.copy.folders}`
    };
    const childFolders = (this.currentFocus
      ? [...(focusFolder?.children || [])].map(path => this.model.folders.get(path))
      : this.model.roots)
      .filter(Boolean)
      .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
    const visibleFolders = childFolders.slice(0, settings.maxFolders);
    const folderNodes = visibleFolders.map(folder => ({
      id: `folder:${folder.path}`,
      type: "folder",
      label: folder.name,
      path: folder.path,
      color: stableColor(folder.path),
      count: folder.count,
      detail: `${folder.count} ${this.copy.notes} · ${folder.children.size} ${this.copy.folders}`
    }));

    let candidateNotes = this.currentFocus ? [...(focusFolder?.files || [])] : [];
    const sampled = new Set();
    if (this.currentFocus && this.currentFocus !== ROOT_NOTES && candidateNotes.length < settings.sampleNotes) {
      const descendants = this.model.files
        .filter(file => file.path.startsWith(`${this.currentFocus}/`))
        .filter(file => !candidateNotes.some(item => item.path === file.path))
        .sort((a, b) => b.stat.mtime - a.stat.mtime);
      for (const file of descendants.slice(0, settings.sampleNotes - candidateNotes.length)) {
        candidateNotes.push(file);
        sampled.add(file.path);
      }
    }
    candidateNotes = candidateNotes.sort((a, b) => b.stat.mtime - a.stat.mtime).slice(0, settings.maxNotes);
    const noteNodes = candidateNotes.map(file => ({
      id: `note:${file.path}`,
      type: "note",
      label: file.basename,
      path: file.path,
      color: stableColor(file.path),
      sample: sampled.has(file.path),
      file,
      detail: `${file.parent?.path || this.copy.rootNotes} · ${formatDate(file.stat.mtime, true, this.locale)}`
    }));

    const nodes = [center, ...folderNodes, ...noteNodes];
    const edges = folderNodes.map(node => ({ source: "center", target: node.id, type: "tree", color: node.color }));
    const folderIds = new Map(folderNodes.map(node => [node.path, node.id]));
    for (const note of noteNodes) {
      let parent = "center";
      if (note.sample) {
        const match = [...folderIds.keys()].filter(path => note.path.startsWith(`${path}/`)).sort((a, b) => b.length - a.length)[0];
        if (match) parent = folderIds.get(match);
      }
      edges.push({ source: parent, target: note.id, type: "tree", color: note.color });
    }

    const visibleNoteIds = new Map(noteNodes.map(node => [node.path, node.id]));
    const crossLinks = new Set();
    for (const note of noteNodes) {
      const resolved = this.app.metadataCache.resolvedLinks[note.path] || {};
      for (const targetPath of Object.keys(resolved)) {
        const target = visibleNoteIds.get(targetPath);
        if (!target || target === note.id) continue;
        const key = [note.id, target].sort().join("::");
        if (crossLinks.has(key)) continue;
        crossLinks.add(key);
        edges.push({ source: note.id, target, type: "cross", color: note.color });
      }
    }
    return {
      nodes,
      edges,
      hiddenFolders: Math.max(0, childFolders.length - visibleFolders.length),
      hiddenNotes: Math.max(0, (focusFolder?.files.length || 0) - candidateNotes.filter(file => !sampled.has(file.path)).length)
    };
  }

  galaxyLayout(nodes, edges) {
    const positions = new Map([["center", { x: GRAPH_CENTER_X, y: GRAPH_CENTER_Y }]]);
    const planets = nodes.filter(node => node.type === "planet");
    const moons = nodes.filter(node => node.type === "moon");
    planets.forEach((node, index) => {
      const angle = -Math.PI / 2 + (index / Math.max(planets.length, 1)) * Math.PI * 2;
      const radialOffset = index % 2 ? 22 : -12;
      positions.set(node.id, {
        x: GRAPH_CENTER_X + Math.cos(angle) * (326 + radialOffset),
        y: GRAPH_CENTER_Y + Math.sin(angle) * (286 + radialOffset * .6)
      });
    });
    const moonsByPlanet = new Map();
    for (const moon of moons) {
      if (!moonsByPlanet.has(moon.parentId)) moonsByPlanet.set(moon.parentId, []);
      moonsByPlanet.get(moon.parentId).push(moon);
    }
    for (const [planetId, group] of moonsByPlanet) {
      const planet = positions.get(planetId);
      if (!planet) continue;
      const outward = Math.atan2(planet.y - GRAPH_CENTER_Y, planet.x - GRAPH_CENTER_X);
      const spread = Math.min(2.65, .8 + group.length * .28);
      group.forEach((moon, index) => {
        const angle = outward - spread / 2 + ((index + .5) / Math.max(group.length, 1)) * spread;
        const ring = index % 2;
        const planetNode = planets.find(item => item.id === planetId);
        const radius = (planetNode?.radius || 24) + 54 + ring * 27;
        positions.set(moon.id, {
          x: planet.x + Math.cos(angle) * radius,
          y: planet.y + Math.sin(angle) * radius
        });
      });
    }
    const comet = nodes.find(node => node.type === "comet");
    if (comet) positions.set(comet.id, { x: 155, y: 145 });
    return positions;
  }

  radialLayout(nodes, edges) {
    const positions = new Map([["center", { x: GRAPH_CENTER_X, y: GRAPH_CENTER_Y }]]);
    const folders = nodes.filter(node => node.type === "folder");
    const notes = nodes.filter(node => node.type === "note");
    const folderAngles = new Map();
    folders.forEach((node, index) => {
      const angle = -Math.PI / 2 + (index / Math.max(folders.length, 1)) * Math.PI * 2;
      const radius = folders.length > 18 && index % 2 ? 340 : 280;
      folderAngles.set(node.id, angle);
      positions.set(node.id, { x: GRAPH_CENTER_X + Math.cos(angle) * radius, y: GRAPH_CENTER_Y + Math.sin(angle) * radius });
    });
    const parentByNote = new Map(edges.filter(edge => edge.type === "tree" && edge.target.startsWith("note:")).map(edge => [edge.target, edge.source]));
    const groups = new Map();
    for (const note of notes) {
      const parent = parentByNote.get(note.id) || "center";
      if (!groups.has(parent)) groups.set(parent, []);
      groups.get(parent).push(note);
    }
    for (const [parent, group] of groups) {
      const base = folderAngles.get(parent) ?? -Math.PI / 2;
      const spread = parent === "center" ? Math.PI * 2 : Math.min(1.65, .28 + group.length * .12);
      group.forEach((node, index) => {
        const angle = base - spread / 2 + ((index + .5) / Math.max(group.length, 1)) * spread;
        const radius = [390, 440, 490][index % 3];
        positions.set(node.id, { x: GRAPH_CENTER_X + Math.cos(angle) * radius, y: GRAPH_CENTER_Y + Math.sin(angle) * radius });
      });
    }
    return positions;
  }

  treeLayout(nodes, edges) {
    if (nodes.some(node => node.type === "planet")) {
      const positions = new Map([["center", { x: 100, y: GRAPH_CENTER_Y }]]);
      const planets = nodes.filter(node => node.type === "planet");
      const moons = nodes.filter(node => node.type === "moon");
      const bandHeight = 930 / Math.max(planets.length, 1);
      planets.forEach((planet, index) => {
        const centerY = 75 + bandHeight * (index + .5);
        positions.set(planet.id, { x: 390, y: centerY });
        const group = moons.filter(moon => moon.parentId === planet.id);
        const columns = Math.max(1, Math.ceil(group.length / 4));
        const rows = Math.max(1, Math.ceil(group.length / columns));
        group.forEach((moon, moonIndex) => {
          const column = Math.floor(moonIndex / rows);
          const row = moonIndex % rows;
          positions.set(moon.id, {
            x: 650 + column * 235,
            y: centerY - ((rows - 1) * 23) / 2 + row * 23
          });
        });
      });
      const comet = nodes.find(node => node.type === "comet");
      if (comet) positions.set(comet.id, { x: 1080, y: 55 });
      return positions;
    }
    const positions = new Map([["center", { x: 110, y: GRAPH_CENTER_Y }]]);
    const folders = nodes.filter(node => node.type === "folder");
    const notes = nodes.filter(node => node.type === "note");
    const columns = Math.max(1, Math.ceil(folders.length / 14));
    const rows = Math.max(1, Math.ceil(folders.length / columns));
    folders.forEach((node, index) => {
      const column = Math.floor(index / rows);
      const row = index % rows;
      positions.set(node.id, {
        x: columns === 1 ? 420 : 270 + column * (440 / Math.max(columns - 1, 1)),
        y: 70 + (row + .5) * (940 / rows)
      });
    });
    notes.forEach((node, index) => positions.set(node.id, {
      x: index % 2 ? 1060 : 850,
      y: 55 + (index + .5) * (970 / Math.max(notes.length, 1))
    }));
    return positions;
  }

  curvePath(source, target) {
    if (this.currentLayout === "tree") {
      const middle = (source.x + target.x) / 2;
      return `M ${source.x} ${source.y} C ${middle} ${source.y}, ${middle} ${target.y}, ${target.x} ${target.y}`;
    }
    const cx = GRAPH_CENTER_X + (source.x + target.x - GRAPH_WIDTH) * .13;
    const cy = GRAPH_CENTER_Y + (source.y + target.y - GRAPH_HEIGHT) * .13;
    return `M ${source.x} ${source.y} Q ${cx} ${cy} ${target.x} ${target.y}`;
  }

  renderStarfield(parent) {
    const layer = createSvg("g", { class: "kap-starfield", "aria-hidden": "true" });
    for (let index = 0; index < 88; index += 1) {
      const x = 22 + (deterministicScore(`star-x:${index}`) % 115600) / 100;
      const y = 20 + (deterministicScore(`star-y:${index}`) % 104000) / 100;
      const radius = .45 + (deterministicScore(`star-r:${index}`) % 150) / 100;
      const star = createSvg("circle", { cx: x, cy: y, r: radius, class: `kap-space-star is-${index % 3}` });
      star.style.animationDelay = `${-(index % 17) * .37}s`;
      layer.appendChild(star);
    }
    parent.appendChild(layer);
  }

  renderGalaxyScenery(parent, data, positions) {
    const scenery = createSvg("g", { class: "kap-galaxy-scenery", "aria-hidden": "true" });
    scenery.appendChild(createSvg("ellipse", {
      cx: GRAPH_CENTER_X,
      cy: GRAPH_CENTER_Y,
      rx: 455,
      ry: 365,
      transform: `rotate(-8 ${GRAPH_CENTER_X} ${GRAPH_CENTER_Y})`,
      class: "kap-galaxy-disk"
    }));
    scenery.appendChild(createSvg("ellipse", {
      cx: GRAPH_CENTER_X,
      cy: GRAPH_CENTER_Y,
      rx: 326,
      ry: 286,
      class: "kap-orbit kap-orbit-primary"
    }));
    scenery.appendChild(createSvg("ellipse", {
      cx: GRAPH_CENTER_X,
      cy: GRAPH_CENTER_Y,
      rx: 348,
      ry: 299,
      class: "kap-orbit kap-orbit-secondary"
    }));
    for (const planet of data.nodes.filter(node => node.type === "planet")) {
      const position = positions.get(planet.id);
      if (!position) continue;
      const moonCount = data.nodes.filter(node => node.type === "moon" && node.parentId === planet.id).length;
      if (!moonCount) continue;
      const orbitRadius = (planet.radius || 24) + 69;
      scenery.appendChild(createSvg("ellipse", {
        cx: position.x,
        cy: position.y,
        rx: orbitRadius,
        ry: orbitRadius * .72,
        transform: `rotate(${(deterministicScore(planet.path) % 70) - 35} ${position.x} ${position.y})`,
        class: "kap-moon-orbit"
      }));
    }
    const comet = data.nodes.find(node => node.type === "comet");
    const cometPosition = comet ? positions.get(comet.id) : null;
    if (cometPosition) {
      scenery.appendChild(createSvg("path", {
        d: `M 24 42 C 62 62, 103 118, ${cometPosition.x} ${cometPosition.y}`,
        class: "kap-comet-arc"
      }));
    }
    parent.appendChild(scenery);
  }

  renderGraph() {
    this.graph.replaceChildren();
    this.renderBreadcrumbs();
    const data = this.getVisibleGraph();
    const positions = this.currentLayout === "radial"
      ? data.overview ? this.galaxyLayout(data.nodes, data.edges) : this.radialLayout(data.nodes, data.edges)
      : this.treeLayout(data.nodes, data.edges);
    this.viewHint.textContent = this.currentLayout === "radial" ? this.copy.orbitHint : this.copy.treeHint;
    this.viewport = createSvg("g", { class: "kap-viewport" });
    this.graph.appendChild(this.viewport);
    this.applyViewTransform();
    this.renderStarfield(this.viewport);
    if (this.currentLayout === "radial") {
      if (data.overview) this.renderGalaxyScenery(this.viewport, data, positions);
      else {
        this.viewport.appendChild(createSvg("circle", { cx: GRAPH_CENTER_X, cy: GRAPH_CENTER_Y, r: 280, class: "kap-orbit" }));
        this.viewport.appendChild(createSvg("circle", { cx: GRAPH_CENTER_X, cy: GRAPH_CENTER_Y, r: 430, class: "kap-orbit kap-orbit-secondary" }));
      }
    }

    const edgeLayer = createSvg("g", { class: "kap-edges" });
    const edgeElements = [];
    for (const edge of data.edges) {
      const source = positions.get(edge.source);
      const target = positions.get(edge.target);
      if (!source || !target) continue;
      const path = createSvg("path", {
        d: this.curvePath(source, target),
        fill: "none",
        class: `kap-edge is-${edge.type}${edge.type === "cross" ? " is-cross" : ""}`,
        "data-source": edge.source,
        "data-target": edge.target
      });
      path.style.setProperty("--kap-edge-color", edge.color);
      edgeLayer.appendChild(path);
      edgeElements.push({ edge, path });
    }
    this.viewport.appendChild(edgeLayer);

    const nodeLayer = createSvg("g", { class: "kap-nodes" });
    const noteParents = new Map(data.edges.filter(edge => edge.type === "tree" && edge.target.startsWith("note:")).map(edge => [edge.target, edge.source]));
    const moonParents = new Map(data.edges.filter(edge => edge.type === "satellite").map(edge => [edge.target, edge.source]));
    const labelCounts = new Map();
    for (const node of data.nodes) {
      const position = positions.get(node.id);
      if (!position) continue;
      const group = createSvg("g", {
        class: `kap-node kap-node-${node.type}`,
        transform: `translate(${position.x} ${position.y})`,
        tabindex: "0",
        role: "button",
        "aria-label": node.label
      });
      group.style.setProperty("--kap-node-color", node.color);
      const coreRadius = node.radius || (node.type === "center" ? 24 : node.type === "folder" ? 13 : 4.2);
      if (node.type === "star") {
        group.appendChild(createSvg("circle", { class: "kap-halo kap-star-halo", r: coreRadius * 1.82 }));
        group.appendChild(createSvg("circle", { class: "kap-star-corona", r: coreRadius * 1.34 }));
        group.appendChild(createSvg("line", { class: "kap-star-flare", x1: -coreRadius * 1.65, x2: coreRadius * 1.65, y1: 0, y2: 0 }));
        group.appendChild(createSvg("line", { class: "kap-star-flare is-vertical", x1: 0, x2: 0, y1: -coreRadius * 1.65, y2: coreRadius * 1.65 }));
        group.appendChild(createSvg("circle", { class: "kap-core", r: coreRadius }));
      } else if (node.type === "planet") {
        group.appendChild(createSvg("circle", { class: "kap-halo", r: coreRadius * 1.58 }));
        group.appendChild(createSvg("ellipse", { class: "kap-planet-ring", rx: coreRadius * 1.48, ry: Math.max(4, coreRadius * .34), transform: "rotate(-16)" }));
        group.appendChild(createSvg("circle", { class: "kap-core", r: coreRadius }));
        group.appendChild(createSvg("path", { class: "kap-planet-shade", d: `M ${-coreRadius * .55} ${-coreRadius * .78} A ${coreRadius} ${coreRadius} 0 0 0 ${coreRadius * .58} ${coreRadius * .8} A ${coreRadius * .82} ${coreRadius * .82} 0 0 1 ${-coreRadius * .55} ${-coreRadius * .78}` }));
      } else if (node.type === "moon") {
        group.appendChild(createSvg("circle", { class: "kap-halo", r: coreRadius * 2.05 }));
        group.appendChild(createSvg("circle", { class: "kap-core", r: coreRadius }));
        group.appendChild(createSvg("circle", { class: "kap-moon-crater", cx: -coreRadius * .24, cy: -coreRadius * .2, r: Math.max(1.2, coreRadius * .22) }));
      } else if (node.type === "comet") {
        group.appendChild(createSvg("line", { class: "kap-comet-tail is-wide", x1: -78, y1: -52, x2: -4, y2: -3 }));
        group.appendChild(createSvg("line", { class: "kap-comet-tail", x1: -58, y1: -39, x2: -3, y2: -2 }));
        group.appendChild(createSvg("circle", { class: "kap-halo", r: coreRadius * 2.8 }));
        group.appendChild(createSvg("circle", { class: "kap-core", r: coreRadius }));
        group.appendChild(createSvg("circle", { class: "kap-comet-spark is-one", cx: -28, cy: -18, r: 1.8 }));
        group.appendChild(createSvg("circle", { class: "kap-comet-spark is-two", cx: -46, cy: -31, r: 1.2 }));
      } else {
        const haloRadius = node.type === "center" ? 42 : node.type === "folder" ? 26 : 13;
        group.appendChild(createSvg("circle", { class: "kap-halo", r: haloRadius }));
        group.appendChild(createSvg("circle", { class: "kap-core", r: coreRadius }));
      }
      if (node.type === "folder" || node.type === "planet") {
        const count = createSvg("text", { x: 0, y: 3, "text-anchor": "middle", class: "kap-label kap-node-count" });
        count.textContent = String(node.count);
        group.appendChild(count);
      }
      let collapse = false;
      if (node.type === "note" && this.currentLayout === "radial") {
        const parent = noteParents.get(node.id) || "center";
        const count = labelCounts.get(parent) || 0;
        collapse = count >= 7;
        labelCounts.set(parent, count + 1);
      }
      const sideFolderLabel = node.type === "folder" && this.currentLayout === "tree";
      let labelX = node.type === "note" ? 10 : sideFolderLabel ? 20 : 0;
      let labelY = node.type === "center" ? 46 : sideFolderLabel ? 3 : node.type === "folder" ? 32 : 3;
      let labelAnchor = node.type === "note" || sideFolderLabel ? "start" : "middle";
      if (node.type === "star") labelY = coreRadius + 28;
      if (node.type === "planet") labelY = coreRadius + 20;
      if (node.type === "comet") {
        labelX = coreRadius + 11;
        labelY = 3;
        labelAnchor = "start";
      }
      if (node.type === "moon") {
        if (this.currentLayout === "tree") {
          labelX = coreRadius + 9;
          labelY = 3;
          labelAnchor = "start";
        } else {
          const parentPosition = positions.get(moonParents.get(node.id));
          const dx = position.x - (parentPosition?.x || GRAPH_CENTER_X);
          const dy = position.y - (parentPosition?.y || GRAPH_CENTER_Y);
          const length = Math.hypot(dx, dy) || 1;
          const ux = dx / length;
          const uy = dy / length;
          labelX = ux * (coreRadius + 9);
          labelY = uy * (coreRadius + 9) + 3;
          labelAnchor = ux > .18 ? "start" : ux < -.18 ? "end" : "middle";
        }
      }
      const label = createSvg("text", {
        x: labelX,
        y: labelY,
        "text-anchor": labelAnchor,
        class: `kap-label ${collapse ? "is-collapsed" : ""}`.trim()
      });
      label.textContent = shortLabel(node.label, node.type === "note" ? 24 : node.type === "moon" ? 16 : 18);
      group.appendChild(label);

      const illuminate = active => {
        for (const item of edgeElements) {
          if (item.edge.source === node.id || item.edge.target === node.id) item.path.classList.toggle("is-lit", active);
        }
      };
      group.addEventListener("mouseenter", () => illuminate(true));
      group.addEventListener("mouseleave", () => illuminate(false));
      const activate = () => {
        if (node.type === "note" || node.type === "comet") this.openNote(node.path);
        else if (node.type === "folder" || node.type === "planet" || node.type === "moon") this.setFocus(node.path);
        else if (node.type === "center" && this.currentFocus) this.setFocus(this.model.folders.get(this.currentFocus)?.parent || "");
      };
      group.addEventListener("click", activate);
      group.addEventListener("keydown", event => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          activate();
        }
      });
      nodeLayer.appendChild(group);
    }
    this.viewport.appendChild(nodeLayer);

    if (!this.currentFocus) this.limitNote.textContent = data.hiddenFolders
      ? `${this.copy.collapsed} · ${data.hiddenFolders} ${this.copy.moreFolders} · ${this.copy.hiddenHint}`
      : this.copy.collapsed;
    else if (data.hiddenFolders || data.hiddenNotes) {
      const parts = [];
      if (data.hiddenFolders) parts.push(`${data.hiddenFolders} ${this.copy.moreFolders}`);
      if (data.hiddenNotes) parts.push(`${data.hiddenNotes} ${this.copy.moreNotes}`);
      this.limitNote.textContent = `${parts.join(" · ")} · ${this.copy.hiddenHint}`;
    } else this.limitNote.textContent = this.copy.complete;
    this.backButton.disabled = !this.currentFocus;
    this.overviewButton.disabled = !this.currentFocus;
  }

  renderBreadcrumbs() {
    this.breadcrumbs.replaceChildren();
    const home = createButton(this.breadcrumbs, "kap-crumb", this.copy.vault);
    home.addEventListener("click", () => this.setFocus(""));
    if (!this.currentFocus) return;
    if (this.currentFocus === ROOT_NOTES) {
      createElement(this.breadcrumbs, "span", "", "›");
      createElement(this.breadcrumbs, "span", "", this.copy.rootNotes);
      return;
    }
    const parts = this.currentFocus.split("/");
    parts.forEach((part, index) => {
      createElement(this.breadcrumbs, "span", "", "›");
      const button = createButton(this.breadcrumbs, "kap-crumb", part);
      button.addEventListener("click", () => this.setFocus(parts.slice(0, index + 1).join("/")));
    });
  }

  setFocus(path) {
    if (path && !this.model.folders.has(path)) return;
    this.currentFocus = path;
    this.resetView(false);
    this.rootElement?.style?.setProperty("--kap-accent", stableColor(path || "Knowledge Atlas"));
    this.renderGraph();
    for (const button of this.domainRail.querySelectorAll(".kap-domain")) {
      button.classList.toggle("is-active", button.textContent.startsWith(`${this.model.folders.get(path)?.name || "\0"} ·`));
    }
  }

  async openNote(path) {
    const file = this.app.vault.getAbstractFileByPath(path);
    if (!(file instanceof TFile)) return;
    const leaf = this.app.workspace.getLeaf(this.plugin.settings.openNotesInNewLeaf);
    await leaf.openFile(file);
  }

  runSearch() {
    const query = this.searchInput.value.trim().toLocaleLowerCase();
    this.searchResults.replaceChildren();
    if (!query) {
      this.searchResults.classList.remove("is-open");
      return;
    }
    const matches = this.model.files
      .map(file => {
        const name = file.basename.toLocaleLowerCase();
        const path = file.path.toLocaleLowerCase();
        const score = name === query ? 0 : name.startsWith(query) ? 1 : name.includes(query) ? 2 : path.includes(query) ? 3 : 99;
        return { file, score };
      })
      .filter(item => item.score < 99)
      .sort((a, b) => a.score - b.score || b.file.stat.mtime - a.file.stat.mtime)
      .slice(0, 10);
    if (!matches.length) createElement(this.searchResults, "div", "kap-search-empty", this.copy.noResults);
    for (const { file } of matches) {
      const button = createButton(this.searchResults, "kap-result", file.basename);
      button.replaceChildren();
      const dot = createElement(button, "span", "kap-result-dot");
      dot.style.setProperty("--kap-result-color", stableColor(file.path));
      const copy = createElement(button, "span", "kap-result-copy");
      createElement(copy, "span", "kap-result-title", file.basename);
      createElement(copy, "span", "kap-result-path", file.parent?.path || this.copy.rootNotes);
      createElement(button, "span", "kap-result-date", formatDate(file.stat.mtime, false, this.locale));
      button.addEventListener("click", () => this.openNote(file.path));
    }
    this.searchResults.classList.add("is-open");
  }

  createZoomControls() {
    const controls = createElement(this.stage, "div", "kap-zoom");
    this.zoomOutButton = createButton(controls, "kap-zoom-button", "−", this.copy.zoomOut);
    this.zoomValue = createElement(controls, "div", "kap-zoom-value", "100%");
    this.zoomInButton = createButton(controls, "kap-zoom-button", "+", this.copy.zoomIn);
    this.zoomResetButton = createButton(controls, "kap-zoom-button is-fit", this.copy.fit, this.copy.fit);
  }

  applyViewTransform() {
    if (this.viewport) {
      const { x, y, k } = this.viewTransform;
      this.viewport.setAttribute("transform", `matrix(${k} 0 0 ${k} ${x} ${y})`);
    }
    if (this.zoomValue) this.zoomValue.textContent = `${Math.round(this.viewTransform.k * 100)}%`;
  }

  resetView(apply = true) {
    this.viewTransform = { x: 0, y: 0, k: 1 };
    if (apply) this.applyViewTransform();
  }

  clientToGraphPoint(event) {
    const matrix = this.graph.getScreenCTM();
    if (matrix) {
      const point = this.graph.createSVGPoint();
      point.x = event.clientX;
      point.y = event.clientY;
      const local = point.matrixTransform(matrix.inverse());
      return { x: local.x, y: local.y };
    }
    const rect = this.graph.getBoundingClientRect();
    return {
      x: (event.clientX - rect.left) * (GRAPH_WIDTH / Math.max(rect.width, 1)),
      y: (event.clientY - rect.top) * (GRAPH_HEIGHT / Math.max(rect.height, 1))
    };
  }

  zoomAt(factor, point = { x: GRAPH_CENTER_X, y: GRAPH_CENTER_Y }) {
    const previous = this.viewTransform.k;
    const next = clamp(previous * factor, .55, 3);
    if (Math.abs(next - previous) < .001) return;
    this.viewTransform.x = point.x - (point.x - this.viewTransform.x) * (next / previous);
    this.viewTransform.y = point.y - (point.y - this.viewTransform.y) * (next / previous);
    this.viewTransform.k = next;
    this.applyViewTransform();
  }

  bindControls() {
    this.rootElement = this.contentEl.querySelector(".kap-root");
    this.backButton.addEventListener("click", () => this.setFocus(this.model.folders.get(this.currentFocus)?.parent || ""));
    this.overviewButton.addEventListener("click", () => this.setFocus(""));
    this.orbitButton.addEventListener("click", () => {
      this.currentLayout = "radial";
      this.resetView(false);
      this.orbitButton.classList.add("is-active");
      this.treeButton.classList.remove("is-active");
      this.renderGraph();
    });
    this.treeButton.addEventListener("click", () => {
      this.currentLayout = "tree";
      this.resetView(false);
      this.treeButton.classList.add("is-active");
      this.orbitButton.classList.remove("is-active");
      this.renderGraph();
    });
    this.refreshButton.addEventListener("click", () => this.render());
    this.layoutButton.addEventListener("click", () => this.setLayoutEditing(!this.layoutEditing));
    this.layoutResetButton.addEventListener("click", () => this.resetDashboardLayout());
    this.searchInput.addEventListener("input", () => this.runSearch());
    this.searchInput.addEventListener("keydown", event => {
      if (event.key === "Escape") {
        this.searchInput.value = "";
        this.runSearch();
        this.searchInput.blur();
      }
    });
    this.searchInput.closest(".kap-search-wrap").addEventListener("focusout", () => {
      window.setTimeout(() => {
        if (!this.searchInput.closest(".kap-search-wrap").contains(document.activeElement)) this.searchResults.classList.remove("is-open");
      }, 0);
    });
    this.zoomOutButton.addEventListener("click", () => this.zoomAt(1 / 1.22));
    this.zoomInButton.addEventListener("click", () => this.zoomAt(1.22));
    this.zoomResetButton.addEventListener("click", () => this.resetView());
    this.graph.addEventListener("wheel", event => {
      event.preventDefault();
      this.zoomAt(event.deltaY < 0 ? 1.14 : 1 / 1.14, this.clientToGraphPoint(event));
    }, { passive: false });
    this.graph.addEventListener("pointerdown", event => {
      if (event.button !== 0 || event.target.closest?.(".kap-node")) return;
      const point = this.clientToGraphPoint(event);
      this.panState = { pointerId: event.pointerId, startX: point.x, startY: point.y, originX: this.viewTransform.x, originY: this.viewTransform.y };
      this.graph.setPointerCapture(event.pointerId);
      this.graph.classList.add("is-panning");
    });
    this.graph.addEventListener("pointermove", event => {
      if (!this.panState || event.pointerId !== this.panState.pointerId) return;
      const point = this.clientToGraphPoint(event);
      this.viewTransform.x = this.panState.originX + point.x - this.panState.startX;
      this.viewTransform.y = this.panState.originY + point.y - this.panState.startY;
      this.applyViewTransform();
    });
    const stopPan = event => {
      if (!this.panState || event.pointerId !== this.panState.pointerId) return;
      if (this.graph.hasPointerCapture(event.pointerId)) this.graph.releasePointerCapture(event.pointerId);
      this.panState = null;
      this.graph.classList.remove("is-panning");
    };
    this.graph.addEventListener("pointerup", stopPan);
    this.graph.addEventListener("pointercancel", stopPan);
    this.graph.addEventListener("dblclick", event => {
      if (!event.target.closest?.(".kap-node")) this.resetView();
    });
  }
}

class KnowledgeAtlasSettingTab extends PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }

  display() {
    const { containerEl } = this;
    containerEl.empty();
    const copy = COPY[resolveLanguage(this.plugin.settings.language)];
    new Setting(containerEl)
      .setName(copy.settingsLanguage)
      .setDesc(copy.settingsLanguageDesc)
      .addDropdown(dropdown => dropdown
        .addOption("auto", copy.languageAuto)
        .addOption("zh", copy.languageChinese)
        .addOption("en", copy.languageEnglish)
        .setValue(this.plugin.settings.language || "auto")
        .onChange(async value => {
          this.plugin.settings.language = value;
          await this.plugin.saveSettings();
          this.display();
        }));
    new Setting(containerEl)
      .setName(copy.settingsStartup)
      .setDesc(copy.settingsStartupDesc)
      .addToggle(toggle => toggle.setValue(this.plugin.settings.openOnStartup).onChange(async value => {
        this.plugin.settings.openOnStartup = value;
        await this.plugin.saveSettings();
      }));
    new Setting(containerEl)
      .setName(copy.settingsExcluded)
      .setDesc(copy.settingsExcludedDesc)
      .addText(text => text
        .setPlaceholder(".obsidian, .trash, Templates, assets")
        .setValue(this.plugin.settings.excludedFolders.join(", "))
        .onChange(async value => {
          this.plugin.settings.excludedFolders = value.split(",").map(item => item.trim()).filter(Boolean);
          await this.plugin.saveSettings();
        }));
    new Setting(containerEl)
      .setName(copy.settingsMaxFolders)
      .setDesc(copy.settingsMaxFoldersDesc)
      .addSlider(slider => slider.setLimits(8, 80, 4).setValue(this.plugin.settings.maxFolders).setDynamicTooltip().onChange(async value => {
        this.plugin.settings.maxFolders = value;
        await this.plugin.saveSettings();
      }));
    new Setting(containerEl)
      .setName(copy.settingsMaxNotes)
      .setDesc(copy.settingsMaxNotesDesc)
      .addSlider(slider => slider.setLimits(12, 120, 6).setValue(this.plugin.settings.maxNotes).setDynamicTooltip().onChange(async value => {
        this.plugin.settings.maxNotes = value;
        await this.plugin.saveSettings();
      }));
    new Setting(containerEl)
      .setName(copy.settingsStaleDays)
      .setDesc(copy.settingsStaleDaysDesc)
      .addSlider(slider => slider.setLimits(30, 730, 30).setValue(this.plugin.settings.staleDays).setDynamicTooltip().onChange(async value => {
        this.plugin.settings.staleDays = value;
        await this.plugin.saveSettings();
      }));
    new Setting(containerEl)
      .setName(copy.settingsRecent)
      .setDesc(copy.settingsRecentDesc)
      .addSlider(slider => slider.setLimits(3, 20, 1).setValue(this.plugin.settings.recentLimit).setDynamicTooltip().onChange(async value => {
        this.plugin.settings.recentLimit = value;
        await this.plugin.saveSettings();
      }));
    new Setting(containerEl)
      .setName(copy.settingsNewTab)
      .setDesc(copy.settingsNewTabDesc)
      .addToggle(toggle => toggle.setValue(this.plugin.settings.openNotesInNewLeaf).onChange(async value => {
        this.plugin.settings.openNotesInNewLeaf = value;
        await this.plugin.saveSettings();
      }));
  }
}

module.exports = class KnowledgeAtlasPlugin extends Plugin {
  async onload() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
    addIcon(ICON_ID, ICON_SVG);
    this.registerView(VIEW_TYPE, leaf => new KnowledgeAtlasView(leaf, this));
    this.addRibbonIcon(ICON_ID, "Open Knowledge Atlas", () => this.activateView());
    this.addCommand({ id: "open-knowledge-atlas", name: "Open Knowledge Atlas", callback: () => this.activateView() });
    this.addCommand({ id: "refresh-knowledge-atlas", name: "Refresh Knowledge Atlas", callback: () => this.refreshViews() });
    this.addSettingTab(new KnowledgeAtlasSettingTab(this.app, this));
    this.app.workspace.onLayoutReady(() => {
      if (this.settings.openOnStartup) this.activateView();
    });
    ["create", "delete", "rename", "modify"].forEach(eventName => {
      this.registerEvent(this.app.vault.on(eventName, () => this.queueRefresh()));
    });
    this.registerEvent(this.app.metadataCache.on("resolved", () => this.queueRefresh()));
  }

  onunload() {
    if (this.refreshTimer) window.clearTimeout(this.refreshTimer);
    this.app.workspace.detachLeavesOfType(VIEW_TYPE);
  }

  async activateView() {
    let leaf = this.app.workspace.getLeavesOfType(VIEW_TYPE)[0];
    if (!leaf) {
      leaf = this.app.workspace.getLeaf(true);
      await leaf.setViewState({ type: VIEW_TYPE, active: true });
    }
    this.app.workspace.revealLeaf(leaf);
    this.app.workspace.setActiveLeaf(leaf, { focus: true });
  }

  queueRefresh() {
    if (this.refreshTimer) window.clearTimeout(this.refreshTimer);
    this.refreshTimer = window.setTimeout(() => this.refreshViews(), 800);
  }

  refreshViews() {
    for (const leaf of this.app.workspace.getLeavesOfType(VIEW_TYPE)) {
      if (leaf.view instanceof KnowledgeAtlasView) leaf.view.render();
    }
  }

  async saveSettings(refresh = true) {
    await this.saveData(this.settings);
    if (refresh) this.refreshViews();
  }
};
