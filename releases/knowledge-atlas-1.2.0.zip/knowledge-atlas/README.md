# Knowledge Atlas

Knowledge Atlas turns any Obsidian vault into an interactive, searchable knowledge map. It scans Markdown files through Obsidian's native API and does not require Dataview or generated index notes.

## Features

- Collapsed overview of top-level knowledge areas
- Drill-down navigation through folders and notes
- Orbit and tree layouts
- Real note-link connections from Obsidian's metadata cache
- Full-vault search and recent-note list
- 53-week note-creation heatmap
- Rolling 12-month growth trajectory and weekday rhythm chart
- Live local clock and activity-aware calendar with month navigation
- Right-side time rail ordered as clock, calendar, heatmap, and trajectory
- Taller graph canvas for denser folder and note exploration
- Mouse-wheel zoom, drag-to-pan, and fit-to-view controls
- Automatic refresh when the vault changes
- Optional automatic opening when Obsidian starts
- Configurable excluded folders and display limits
- Chinese and English interface controlled from plugin settings
- Desktop and mobile compatible

Activity charts prefer the note's `created` frontmatter value and fall back to Obsidian's file creation time when that property is unavailable.

## Manual installation

1. Download `knowledge-atlas-1.2.0.zip` from `releases/`.
2. Extract the `knowledge-atlas` folder into:

   ```text
   <your-vault>/.obsidian/plugins/
   ```

3. In Obsidian, open **Settings → Community plugins**.
4. Reload installed plugins if needed, then enable **Knowledge Atlas**.
5. Click the network icon in the ribbon or run **Knowledge Atlas: Open Knowledge Atlas** from the command palette.

You can also install manually by copying `main.js`, `manifest.json`, and `styles.css` into `.obsidian/plugins/knowledge-atlas/`.

## Settings

- **Excluded folders**: comma-separated folder paths or prefixes that should not appear in the atlas.
- **Maximum folders**: maximum folder nodes drawn in one view.
- **Maximum notes**: maximum note nodes drawn in one view.
- **Recent notes**: number of recently modified notes shown in the side panel.
- **Open notes in a new tab**: opens note nodes without replacing the atlas view.
- **Interface language**: follows the system language or stays in Chinese/English.
- **Open Atlas on startup**: makes Knowledge Atlas the first view shown after the workspace loads.

The default overview stays collapsed. Notes are loaded only after entering a knowledge area.

## Public release checklist

Before submitting this plugin to the Obsidian Community directory:

1. Replace the placeholder contributor name in `manifest.json` and `LICENSE` if desired.
2. Publish the project as a public GitHub repository.
3. Create a GitHub release tagged exactly `1.2.0`.
4. Attach `main.js`, `manifest.json`, and `styles.css` to the release.
5. Submit the repository through the Obsidian Community plugin directory.

## Privacy

Knowledge Atlas runs locally. It does not send vault content to external services and does not use network requests.
