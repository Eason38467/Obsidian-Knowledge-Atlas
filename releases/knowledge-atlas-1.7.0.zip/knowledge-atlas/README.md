# Knowledge Atlas

Knowledge Atlas turns any Obsidian vault into an interactive, searchable knowledge map. It scans Markdown files through Obsidian's native API and does not require Dataview or generated index notes.

## Features

- Galaxy overview with a vault star, top-level folder planets, and second-level folder moons
- Procedural 3D planet surfaces with directional lighting, atmosphere, terrain, storms, gas bands, and selective rings
- Directory mass controls planet and moon size without allowing large folders to overwhelm the canvas
- Root-level `AGENTS.md` appears as an animated comet with a direct-open action
- Tilted, perspective orbital plane inspired by a solar-system view
- Live planet, moon, and comet revolution with visible celestial self-rotation
- Evenly spaced satellite rings whose orbital motion remains independent from planet self-rotation
- Hover-to-pause inspection for stars, planets, moons, and the root comet
- Canvas motion controls with pause/resume and a persistent 0.25×–3× speed range
- Drill-down navigation through folders and notes
- Orbit and tree layouts
- Real note-link connections from Obsidian's metadata cache
- Full-vault search and recent-note list
- 53-week note-creation heatmap
- Rolling 12-month growth trajectory and weekday rhythm chart
- Live local clock and activity-aware calendar with month navigation
- Right-side time rail ordered as clock, calendar, heatmap, and trajectory
- Taller graph canvas for denser folder and note exploration
- Knowledge health checks for orphan notes, broken links, and stale notes
- Clickable heatmap days with direct access to notes created on that day
- Stable daily review of three older notes
- Shared folder, tag, and time-range filters for heatmap and trajectory data
- Mouse-wheel zoom, drag-to-pan, and fit-to-view controls
- Canvas zoom controls anchored at the upper-right corner
- Free layout editor for moving and resizing the galaxy canvas and every dashboard panel
- Persistent custom positions, sizes, and stacking order with responsive width adaptation
- One-click layout reset and an automatic compact-screen fallback
- Automatic refresh when the vault changes
- Optional automatic opening when Obsidian starts
- Configurable excluded folders and display limits
- Chinese and English interface controlled from plugin settings
- Desktop and mobile compatible

Activity charts prefer the note's `created` frontmatter value and fall back to Obsidian's file creation time when that property is unavailable.

## Manual installation

1. Download `knowledge-atlas-1.7.0.zip` from `releases/`.
2. Extract the `knowledge-atlas` folder into:

   ```text
   <your-vault>/.obsidian/plugins/
   ```

3. In Obsidian, open **Settings → Community plugins**.
4. Reload installed plugins if needed, then enable **Knowledge Atlas**.
5. Click the network icon in the ribbon or run **Knowledge Atlas: Open Knowledge Atlas** from the command palette.

You can also install manually by copying `main.js`, `manifest.json`, and `styles.css` into `.obsidian/plugins/knowledge-atlas/`.

## Settings

- **Excluded folders**: comma-separated folder paths or prefixes that should not appear in the atlas.
- **Maximum folders**: maximum folder nodes drawn in one view.
- **Maximum notes**: maximum note nodes drawn in one view.
- **Recent notes**: number of recently modified notes shown in the side panel.
- **Open notes in a new tab**: opens note nodes without replacing the atlas view.
- **Interface language**: follows the system language or stays in Chinese/English.
- **Open Atlas on startup**: makes Knowledge Atlas the first view shown after the workspace loads.
- **Stale note threshold**: controls how many inactive days mark a note as stale.

The default overview stops at the second folder level. Notes are loaded only after entering a knowledge area.

## Layout editing

1. Select **Arrange layout** in the atlas toolbar.
2. Drag the upper-left handle of the canvas or any panel to move it.
3. Drag the lower-right handle to resize it. The most recently selected item moves to the front.
4. Select **Done** to save the layout, or **Reset** to restore the default two-column arrangement.

Custom layouts are stored in the plugin settings. Horizontal positions and widths adapt when the Obsidian pane changes size. Screens narrower than 720 pixels use the standard responsive layout.

## Galaxy motion

- Use the play/pause button inside the galaxy canvas to stop or resume motion.
- Use the adjacent slider to set the shared motion rate from `0.25×` to `3×`.
- Top-level folders keep readable angular spacing while orbiting on wider, more strongly separated tracks.
- Satellites are distributed evenly across one or two rings. Each ring has a shared orbital rate, while every moon keeps its own visual self-rotation.
- Hover a celestial body to freeze the whole system for inspection; motion resumes when the pointer leaves.
- Tree mode pauses the animation automatically. Returning to Galaxy mode resumes it.
- The operating system's reduced-motion preference disables automatic motion.

## Public release checklist

Before submitting this plugin to the Obsidian Community directory:

1. Replace the placeholder contributor name in `manifest.json` and `LICENSE` if desired.
2. Publish the project as a public GitHub repository.
3. Create a GitHub release tagged exactly `1.7.0`.
4. Attach `main.js`, `manifest.json`, and `styles.css` to the release.
5. Submit the repository through the Obsidian Community plugin directory.

## Privacy

Knowledge Atlas runs locally. It does not send vault content to external services and does not use network requests.
